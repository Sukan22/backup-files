from typing import List, Dict
import logging

logger = logging.getLogger("RequirementAI")

class TraceabilityAgent:
    def run(self, inputs: Dict) -> Dict:
        classified = {r["requirement_id"]: r for r in inputs.get("classified", [])}
        validated = {r["requirement_id"]: r for r in inputs.get("validated", [])}
        user_stories = {r["requirement_id"]: r for r in inputs.get("user_stories", [])}
        gherkin = {r["requirement_id"]: r for r in inputs.get("gherkin_scenarios", [])}
        test_cases = inputs.get("test_cases", [])

        # --- Index user stories by requirement_id ---
        us_map: Dict[str, List[Dict]] = {}
        for us in inputs.get("user_stories", []):
            rid = us.get("requirement_id")
            if rid:
                us_map.setdefault(rid, []).append(us)

        # --- Index test cases by requirement_id + user_story_id ---
        tc_map: Dict[str, Dict[str, List[Dict]]] = {}
        for tc in test_cases:
            rid = tc.get("requirement_id")
            uid = tc.get("user_story_id")
            if rid and uid:
                tc_map.setdefault(rid, {}).setdefault(uid, []).append(tc)

        all_ids = sorted(set(
            list(classified.keys())
            + list(validated.keys())
            + list(user_stories.keys())
            + list(gherkin.keys())
            + [tc.get("requirement_id") for tc in test_cases if "requirement_id" in tc]
        ))

        logger.info(f"Building traceability matrix for {len(all_ids)} requirements.")

        traceability = []

        for rid in all_ids:
            trace = {
                "requirement_id": rid,
                "requirement_text": classified.get(rid, {}).get("requirement_text", ""),
                "requirement_type": classified.get(rid, {}).get("requirement_type", ""),
                "confidence_score": classified.get(rid, {}).get("confidence_score", 0.0),
                "llm_check_passed": validated.get(rid, {}).get("validation", {}).get("llm_check_passed", False),
                "validation_issues": validated.get(rid, {}).get("validation", {}).get("issues", []),
                "gherkin_feature": gherkin.get(rid, {}).get("feature", ""),
                "gherkin_scenarios": gherkin.get(rid, {}).get("scenarios", []),

                # --- New nested mapping ---
                "user_stories": []
            }

            for us in us_map.get(rid, []):
                us_entry = {
                    "user_story_id": us.get("user_story_id"),
                    "user_story": us.get("user_story", ""),
                    "acceptance_criteria": us.get("acceptance_criteria", []),
                    "test_cases": tc_map.get(rid, {}).get(us.get("user_story_id"), [])
                }
                trace["user_stories"].append(us_entry)

            traceability.append(trace)

        return {"traceability": traceability}