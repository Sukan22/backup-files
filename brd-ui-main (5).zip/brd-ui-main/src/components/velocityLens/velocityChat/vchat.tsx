"use client";

import { useState, useRef, useEffect, type JSX } from "react";
import { Input } from "@/components/ui/input";
import  { type ChatItem } from "./ChatHistoryPopup";
import { Bot } from "lucide-react";
// import {
//   Accordion,
//   AccordionContent,
//   AccordionItem,
//   AccordionTrigger,
// } from "@/components/ui/accordion";
import remarkGfm from "remark-gfm"; 
//import { SearchChatPopup } from "./SearchChatPopup";
import axios from "axios";
import ReactMarkdown from "react-markdown";
import { AnimatePresence, motion } from "framer-motion";

interface ContentProps {
    
  chatHistory: ChatItem[];
setChatHistory: React.Dispatch<React.SetStateAction<ChatItem[]>>;

  resetSignal?: number;
  showSearchModal?: boolean;
  setShowSearchModal: (value: boolean) => void;
}

export default function VelocityChat({chatHistory,setChatHistory, resetSignal, showSearchModal,setShowSearchModal }: ContentProps) {
  const [inputText, setInputText] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  // const [chatHistory, setChatHistory] = useState<
  //   { question: string; answer: string | JSX.Element }[]
  // >([]);
 // const [chatHistory, setChatHistory] = useState<ChatItem[]>([]);
  const chatEndRef = useRef<HTMLDivElement>(null);
  // const [showSearchModal, setShowSearchModal] = useState(false);
    // const [input, setInput] = useState("");
  const [response, setResponse] = useState("");

//  const [searchKeyword, setSearchKeyword] = useState("");
// const [filteredChats, setFilteredChats] = useState<ChatItem[]>([]);



  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatHistory, isGenerating]);

   useEffect(() => {
  if (chatHistory.length > 0) return; // don't clear if already chatting
  setInputText("");
  setResponse("");
}, [resetSignal]);


  // const handleSend = () => {
  //   if (!inputText.trim()) return;

  //   const currentQuestion = inputText.trim();
  //   setInputText("");
  //   setIsGenerating(true);

  //   setTimeout(() => {
  //     setIsGenerating(false);
  //     const generatedAnswer = getAnswerForQuestion(currentQuestion);

  //     setChatHistory((prev) => [
  //       ...prev,
  //       { question: currentQuestion, answer: generatedAnswer },
  //     ]);
  //   }, 2000);
  // };

 const loadingMessages = ["Thinking...",
"Generating...",
"Analyzing...",
"Generating Insights...",
"Preparing your answer...",
];

const ensureNumberedSections = (text: string): string => {
  const sections = text.split(/\n(?=\*\*)/); // split by heading-style sections
  return sections
    .map((section, index) => {
      if (section.trim().startsWith("**")) {
        return `${index + 1}. ${section.trim()}`;
      }
      return section;
    })
    .join("\n");
};

const handleSend = async () => {
  if (!inputText.trim()) return;

  const currentQuestion = inputText.trim();
  setInputText("");
  setIsGenerating(true);

  let loadingIndex = 0;

  const AnimatedPlaceholder = () => {
    const [message, setMessage] = useState(loadingMessages[0]);

    useEffect(() => {
      const interval = setInterval(() => {
        loadingIndex = (loadingIndex + 1) % loadingMessages.length;
        setMessage(loadingMessages[loadingIndex]);
      }, 3000);

      return () => clearInterval(interval);
    }, []);

    return (
      <p className="text-black dark:text-white">
        <span className="inline-flex items-center gap-2">
          <Bot className="w-4 h-4" />
          <AnimatePresence mode="wait">
            <motion.span
              key={message}
              initial={{ opacity: 0, x: 5 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -2 }}
              transition={{ duration: 0.4 }}
              className="inline-block"
            >
              {message}
            </motion.span>
          </AnimatePresence>
        </span>
      </p>
    );
  };

  // Show animated placeholder
  setChatHistory((prev) => [
    ...prev,
    {
      question: currentQuestion,
      answer: <AnimatedPlaceholder />,
    },
  ]);

  // const fetchAnswerFromAPI = async (question: string): Promise<JSX.Element> => {
  //   try {
  //     const response = await axios.post("http://10.73.81.34:8082/chat", {
  //       message: question,
  //       username: "ekzhu",
  //       max_results: 15,
  //       similarity_threshold: 0.5,
  //     });

  //     const data = response.data;
  //     console.log("API Response:", data.response);
  //     return (
  //       <p className="prose dark:prose-invert max-w-none">
  //           <ReactMarkdown remarkPlugins={[remarkGfm]}>
  //        {ensureNumberedSections(data.response)}
  //       </ReactMarkdown>
  //       </p>
  //     );
  //   } catch (error) {
  //     console.error("Error fetching answer:", error);
  //     return <p className="text-red-500">Error fetching answer. Please try again.</p>;
  //   }
  // };

  // Fetch actual response
  const generatedAnswer = await getAnswerForQuestion(currentQuestion);

  // Replace placeholder with real answer
setTimeout(() => {
  setChatHistory((prev) => {
    const updated = [...prev];
    updated[updated.length - 1] = {
      ...updated[updated.length - 1],
      answer: generatedAnswer,
    };
    return updated;
  });

  setIsGenerating(false);
}, 15000); 

};

const getAnswerForQuestion = (question: string): JSX.Element => {
  if (
    question ===
    "What is the pull request activity for ekzhu in the datasketch repo?"
  ) {
   return (
  <div className="space-y-5 text-black dark:text-white">
    <p >
      Based on the provided GitHub activity data for the user ekzhu, here is a comprehensive developer velocity analysis:
    </p>

    <div>
      <h2 className="font-semibold text-lg">1. Activity Summary</h2>
      <p>Total Activities: <span className="font-medium">20 activities</span> were found across the specified date range.</p>
      <p>Activity Type Breakdown:</p>
      <ul className="list-disc pl-6 space-y-1">
        <li><span className="font-semibold">Comments: </span><span className="font-medium">13 activities</span> (65% of total). These include both pull request comments and issue comments.</li>
        <li><span className="font-semibold">Repositories:</span> <span className="font-medium">4 activities</span> (20% of total). These represent new repository creations.</li>
        <li><span className="font-semibold">Pull Requests:</span> <span className="font-medium">3 activities</span> (15% of total). All listed pull requests are closed.</li>
      </ul>
    </div>

    <div>
      <h2 className="font-semibold text-lg">2. Temporal Analysis</h2>
      <p><span className="font-semibold">Overall Period:</span> The activities span from 2015-09-16 to 2025-01-18.</p>
      <p><span className="font-semibold">Recent Activity (~1.5 years):</span></p>
      <ul className="list-disc pl-6 space-y-1">
        <li><span className="font-medium">2025-01-18:</span> 3 new repositories (<code>ekzhu/llm-course</code>, <code>ekzhu/SciAgentsDiscovery</code>, <code>ekzhu/AIOpsLab</code>) were created.</li>
        <li><span className="font-medium">2024-03-11:</span> 2 comments were made on <code>ekzhu/datasketch</code> pull request #232.</li>
        <li><span className="font-medium">2023-09-06:</span> 1 pull request (<code>ekzhu/datasketch PR #222</code>) was closed.</li>
      </ul>
      <p><span className="font-semibold">Historical Patterns:</span> Activity is sporadic, with a gap from 2021-06-03 to 2023-09-06. Most consistent contributions appear in <code>ekzhu/datasketch</code> and <code>ekzhu/SetSimilaritySearch</code>.</p>
    </div>

    <div>
      <h2 className="font-semibold text-lg">3. Repository Engagement</h2>
        <ul className="list-disc pl-6 space-y-1">
      <li><span className="font-semibold">Most Active Repository:</span> <code>ekzhu/datasketch</code> with 3 pull requests and at least 3 comments over the years.</li>
      <li><span className="font-semibold">Other Engaged Repositories:</span>
    
        <code>ekzhu/SetSimilaritySearch</code> – 2 comments on issues, suggesting community interaction.</li>
        <li><span className="font-semibold">New Repositories</span><code>ekzhu/llm-course</code>, <code>ekzhu/SciAgentsDiscovery</code>, <code>ekzhu/AIOpsLab</code> – newly created on 2025-01-18.</li>
        <li><span className="font-semibold">Limited Activity</span><code>ekzhu/OpenCEP</code> – one repo creation in 2021.
        <code>ekzhu/lsh</code> – listed but no detailed activity provided.</li>
      </ul>
    </div>

    <div>
      <h2 className="font-semibold text-lg">4. Velocity Metrics</h2>
      <ul className="list-disc pl-6 space-y-1">
        <li><span className="font-semibold">Overall Velocity:</span> ~2.2 activities/year over 9 years.</li>
        <li><span className="font-semibold">Recent Velocity (~1.5 years):</span> 6 activities – 3 repo creations, 2 comments, 1 PR.</li>
        <li><span className="font-semibold">Pull Request Velocity:</span> 3 total, all closed, focused on <code>ekzhu/datasketch</code>.</li>
        <li><span className="font-semibold">Commit Velocity:</span> No direct data, but low PR count suggests low commit frequency.</li>
      </ul>
    </div>

    <div>
      <h2 className="font-semibold text-lg">5. Collaboration Indicators</h2>
      <ul className="list-disc pl-6 space-y-1">
        <li><span className="font-semibold">Code Reviews & Discussions:</span> 3 PR comment activities (e.g., <code>ekzhu/datasketch PR #232</code> and #53) indicate code review involvement.</li>
        <li><span className="font-semibold">Community Engagement:</span> 2 issue comments on <code>ekzhu/SetSimilaritySearch</code> issues #10 and #4, showing community responsiveness.</li>
        <li><span className="font-semibold">Overall:</span> Not highly active, but there is evidence of code review, issue discussions, and moderate collaboration focused on two main repos.</li>
      </ul>
    </div>
  </div>
);

  }
  if (
  question ===
    "Provide a metric based developer velocity for user ekzhu based on his github activity records."
  
) {
  return (
    <div className="space-y-4 text-black dark:text-white text-sm leading-relaxed">
      <p>
        Here’s a <strong>professional, metric-based developer velocity analysis</strong> for user <code>ekzhu</code> based on the activity records you shared, along with interpretation and recommendations grounded in industry best practices.
      </p>

      <h2 className="font-semibold text-base mt-4">1. Activity Summary (by Type)</h2>
      <ul className="list-disc pl-5">
        <li><strong>Repositories:</strong> 4</li>
        <li><strong>Comments:</strong> 13 (across issues and PRs)</li>
        <li><strong>Pull Requests:</strong> 3</li>
      </ul>

      <h2 className="font-semibold text-base mt-4">2. Time-based Analysis</h2>
      <ul className="list-disc pl-5">
        <li><strong>Oldest activity:</strong> January 20, 2016 (comment)</li>
        <li><strong>Most recent activity:</strong> March 11, 2024 (comment)</li>
        <li><strong>PRs:</strong> November 24, 2019 → September 6, 2023</li>
        <li><strong>Repository creation:</strong> January 2025 (possibly future-dated)</li>
      </ul>
      <p><strong>Recent 12-months:</strong> 1 PR, 1–2 comments — activity is sparse</p>

      <h2 className="font-semibold text-base mt-4">3. Repository Focus</h2>
      <p>Most PRs/comments occur in <code>ekzhu/datasketch</code>. Other repos show minimal engagement.</p>

      <h2 className="font-semibold text-base mt-4">4. Velocity Metrics</h2>
      <ul className="list-disc pl-5">
        <li><strong>PR creation rate:</strong> ~0.6/year</li>
        <li><strong>Comments:</strong> Periodic, not sustained</li>
        <li><strong>No commit data:</strong> true commit frequency is unknown</li>
      </ul>

      <h2 className="font-semibold text-base mt-4">5. Benchmark Comparison</h2>
      <p>
        Compared to <strong>DORA/SPACE benchmarks</strong> (5–20 PRs/year, weekly commits), current activity is well below average for active contributors.
      </p>

      <h2 className="font-semibold text-base mt-4">6. Collaboration & Trends</h2>
      <ul className="list-disc pl-5">
        <li>Participation in comments and reviews is present, but limited</li>
        <li>Latest burst in March 2024</li>
        <li>No consistent PR flow or frequent merges</li>
      </ul>

      <h2 className="font-semibold text-base mt-4">7. Expert Recommendations</h2>
      <ul className="list-disc pl-5">
        <li><strong>Increase cadence:</strong> Aim for 1 PR/month across repos</li>
        <li><strong>Enhance collaboration:</strong> Engage in PR reviews/discussions</li>
        <li><strong>Leverage automation:</strong> Use GitHub Actions, templates, project boards</li>
        <li><strong>Track metrics monthly:</strong> PRs, comments, commit counts</li>
        <li><strong>If project is archival:</strong> No action needed, low velocity is acceptable</li>
      </ul>

      <p className="italic text-gray-500 dark:text-gray-400">
        Note: This analysis is based only on the listed activity. Additional data (e.g., commits, issues, merged PRs) may provide more accurate metrics.
      </p>
    </div>
  );
}

  if (question.toLowerCase().includes("pps-data-all")) {
    return (
      <p>
        <strong className="text-[#38DEEB]">PPS-DATA-ALL</strong> stores various intermediate values during the payment calculation like wage index, LOS, site-neutral and standard payment components. It acts like a centralized memory for all PPS-related computations.
      </p>
    );
  }

  return <p className="text-black dark:text-white">Sorry, I don’t have an answer for that yet.</p>;
};

  const isChatStarted = chatHistory.length > 0 || isGenerating;

  return (
    <div
      className={`flex flex-col h-[82vh] text-white relative ${
        isChatStarted ? "justify-between" : "justify-center"
      } items-center`}
    >
      {/* Chat History */}
      {isChatStarted && (
        <div className="flex flex-col items-center overflow-y-auto px-6 pt-6 space-y-2 w-full h-[67vh]">
          {chatHistory.map((chat, index) => (
            <div key={index} className="space-y-2 w-[44vw]">
              <div className="flex justify-end">
                <div className="bg-[#ececec] dark:bg-[#525252] px-3 py-2 rounded-[10px] text-xs text-black dark:text-white max-w-xl">
                  {chat.question}
                </div>
              </div>

              <div className="flex justify-start">
                <div className="px-3 py-2 rounded-lg text-[12px] tracking-wider text-gray-300 whitespace-pre-wrap ">
                  {typeof chat.answer === "string" ? (
  <pre>{chat.answer}</pre>
) : (
  chat.answer
)}
                </div>
              </div>
            </div>
          ))}

        {/* <div className="flex justify-start items-center w-[44vw]">
        {isGenerating && (
          <div className="text-white animate-pulse text-sm">
            Generating...
          </div>
        )}
        </div> */}
          <div ref={chatEndRef} />
        </div>
      )}
      {/* {showHistory && (
        <ChatHistorySidebar
          chatHistory={chatHistory}
          onClose={onCloseHistory}
            onDelete={(index) => {
      console.log("Deleting index:", index); // Debug log
      setChatHistory((prev) => prev.filter((_, i) => i !== index));
    }}

    
        />
      )} */}
{/* {showSearchModal && (
  <SearchChatModal
  open={showSearchModal}
  onClose={() => {
    setShowSearchModal(false);
    setSearchKeyword(""); // clear search on close
    setFilteredChats([]); // reset
  }}
  onSearch={(keyword) => {
    setSearchKeyword(keyword);
   const lowerKeyword = keyword.toLowerCase();
const matches = chatHistory.filter(chat =>
  chat.question.toLowerCase().includes(lowerKeyword) ||
  (typeof chat.answer === "string" && chat.answer.toLowerCase().includes(lowerKeyword))
);
    setFilteredChats(matches);
  }}
/>

)} */}
       
      {/* Input Box */}
      <div
        className={`w-full flex flex-col items-center ${
          isChatStarted ? "pb-0" : ""
        }`}
      >
        {/* Welcome Prompt on First Load */}
        {!isChatStarted && (
  <>
    <h4 className="text-black dark:text-white dark:text-3xl text-3xl mb-4">Try Asking</h4>

    <div className="flex flex-wrap justify-center gap-3 mb-4">
      {[
        "What is the pull request activity for ekzhu in the datasketch repo?",
        "what is the developer velocity of ekzhu for last 90 days?",
        "what proportion of work goes unreviewed?what is the average time to close an issue?",
        "Provide a metric based developer velocity for user ekzhu based on his github activity records.",
      ].map((question, index) => (
        <button
          key={index}
          onClick={() => {
            setInputText(question);
            handleSend();
          }}
          className="bg-[#ececec] dark:bg-[#2F2F2F] text-xs h-12 text-black dark:text-white  border border-[#d0d0d0] dark:border-[#707070] px-4 py-2 rounded-xl hover:bg-gray-400 dark:hover:bg-[#3c3c3c] transition"
        >
          {question} 
        </button>
      ))}
    </div>
  </>
)}


        <div className="relative w-[45vw]">
          <Input
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSend()}
            className="w-full h-[12vh] !bg-[#ececec] dark:!bg-[#2E2D2D]  text-black dark:text-white rounded-xl border-none outline-none focus:outline-none focus:ring-0 pr-12  placeholder:text-gray-700 dark:placeholder:text-gray-400"
            placeholder="Ask me about development data, team performance, or project insights…"
          />
          <button
            onClick={handleSend}
            className="absolute right-1.5 top-1/2 -translate-y-1/2"
            
          >
            
           <svg xmlns="http://www.w3.org/2000/svg" width="37" height="37" viewBox="0 0 44 44">
    <g id="Group_119" data-name="Group 119" transform="translate(-1419 -567.719)">
      <circle id="Ellipse_7" data-name="Ellipse 7" cx="22" cy="22" r="22" transform="translate(1419 567.719)" fill="#b164ff"/>
      <g id="bx-right-arrow-alt" transform="translate(1430.158 579.158)">
        <path id="Path_92" data-name="Path 92" d="M56.445,61.491,58.7,63.747l10.7-10.7-10.7-10.7L56.445,44.6l6.85,6.85H48v3.191H63.3Z" transform="translate(-48 -42.344)" fill="#fff"/>
      </g>
    </g>
  </svg>
          </button>
        </div>
      </div>
    </div>
  );
}


// function highlightText(text: string, keyword: string): JSX.Element {
//   if (!keyword) return <>{text}</>;

//   const parts = text.split(new RegExp(`(${keyword})`, 'gi'));
//   return (
//     <>
//       {parts.map((part, index) =>
//         part.toLowerCase() === keyword.toLowerCase() ? (
//           <mark key={index} className="bg-yellow-400 text-black rounded px-1">{part}</mark>
//         ) : (
//           <span key={index}>{part}</span>
//         )
//       )}
//     </>
//   );
// }
