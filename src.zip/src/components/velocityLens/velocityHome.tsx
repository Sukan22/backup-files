'use client';

// import React from 'react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
// import { Button } from "@/components/ui/button";
import { Github, Slack, MonitorCog } from "lucide-react";
import { cn } from "@/lib/utils";
import { useEffect, useState } from "react";
import { VelocityextractIcon ,CompletedVelocityIcon, ChatVelocityIcon } from '../icons/appIcons';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';


export default function VelocityLens() {
    const [currentStep, setCurrentStep] = useState(1); // Start at Step 1
const [progress, setProgress] = useState(0);
const [loadingText, setLoadingText] = useState("Fetching User data...");
const [loadingDescription, setLoadingDescription] = useState("");
const [highlightSteps, setHighlightSteps] = useState<number[]>([1]);
// const [iconType, setIconType] = useState<"loading" | "thinking" | "success">("loading");
const navigate = useNavigate();
const [username, setUsername] = useState("");
const [token, setToken] = useState("");
const [maxPages, setMaxPages] = useState("");
// const extractUserData = async () => {
//   const res = await fetch("/api/extract", {
//     method: "POST",
//     body: JSON.stringify({ username, token, maxPages }),
//     headers: { "Content-Type": "application/json" }
//   });
//   if (!res.ok) throw new Error("Extraction failed");
//   return res.json();
// };

// const generateGraphDatabase = async () => {
//   const res = await fetch("/api/generate-graph", {
//     method: "POST",
//     headers: { "Content-Type": "application/json" }
//   });
//   if (!res.ok) throw new Error("Graph generation failed");
//   return res.json();
// };
function pollStatus(extraction_id: string) {
 
  axios
    .get(`http://10.73.81.34:8081/status/${extraction_id}`)
    .then((res) => {
      const status = res.data.status;
      console.log(`📥 Status response: ${status}`);

      if (status === "completed") {
        setLoadingText("Completed Successfully");
        setProgress(100);

        setTimeout(() => {
          setLoadingText("Let's ask something…");
          setHighlightSteps([1, 2, 3]);
        }, 1500);
      } else if (status === "processing") {
        setTimeout(() => pollStatus(extraction_id), 10000); // Retry in 10s
      } else {
        setLoadingText("Extraction failed.");
        console.error(`❌ Unexpected status: ${status}`);
        alert("❗ Extraction failed or unknown status.");
      }
    })
    .catch((err) => {
      console.error("⚠️ Error checking extraction status:", err);
      alert("⚠️ Failed to check extraction status.");
    });
}
function animateProgress(from: number, to: number, duration: number) {
  const steps = to - from;
  const intervalTime = duration / steps;
  let current = from;

  const interval = setInterval(() => {
    current += 1;
    setProgress(current);
    if (current >= to) clearInterval(interval);
  }, intervalTime);
}


// useEffect(() => {
//   if (currentStep === 2) {
//     setProgress(0);
//     setHighlightSteps([1]);
//    // setIconType("loading");

//     const timeouts = [
//       setTimeout(() => {
//         setLoadingText("Extracting User data...");
//         setProgress(30);
//       }, 3000),

//       setTimeout(() => {
//         setLoadingText("Generating Graph Database...");
//         setProgress(60);
//         setHighlightSteps([1, 2]);
//       }, 6000),

//       setTimeout(() => {
//         setLoadingText("Completed Successfully");
//         setProgress(90);
//         setHighlightSteps([1, 2]);
//         //setIconType("thinking");
//       }, 9000),

//       setTimeout(() => {
//         setLoadingText("Let's ask something…");
//         setProgress(100);
//         setHighlightSteps([1, 2, 3]);
//         //setIconType("success");
//       }, 12000),
//     ];

//     return () => timeouts.forEach(clearTimeout);
//   }
// }, [currentStep]);
 const getCurrentIcon = () => {
  if (loadingText === "Completed Successfully") return <CompletedVelocityIcon />;
  if (loadingText === "Let's ask something…") return <ChatVelocityIcon />;
  return <VelocityextractIcon />;
};
const [animatedDots, setAnimatedDots] = useState("");

useEffect(() => {
  if (loadingText === "Still processing…") {
    const interval = setInterval(() => {
      setAnimatedDots((prev) => (prev.length >= 3 ? "" : prev + "."));
    }, 500);
    return () => clearInterval(interval); // Cleanup
  } else {
    setAnimatedDots(""); // Reset when not "Still processing…"
  }
}, [loadingText]);

  const JiraIcon = ({ className = "" }: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="17"
    height="17"
    viewBox="0 0 17.54 17.912"
    className={className}
    fill="none"
    stroke="currentColor"
  >
    <g transform="translate(-221.718 -19.757)">
      <path
        d="M530.292,1837.281c.055-.055,6.941,0,6.941,0a.835.835,0,0,1,.9.917c0,.989.07,7.14,0,7.143s-2.805-.615-2.87-2.5-.055-2.516-.207-2.668-2.333.117-2.966-.248A8.538,8.538,0,0,1,530.292,1837.281Z"
        transform="translate(-308.125 -1808.173)"
        strokeWidth="1"
      />
      <path
        d="M530.292,1837.281c.055-.055,6.941,0,6.941,0a.835.835,0,0,1,.9.917c0,.989.07,7.14,0,7.143s-2.805-.615-2.87-2.5-.055-2.516-.207-2.668-2.333.117-2.966-.248A8.538,8.538,0,0,1,530.292,1837.281Z"
        transform="translate(-304.187 -1812.969)"
        strokeWidth="1"
      />
      <path
        d="M530.292,1837.281c.055-.055,6.941,0,6.941,0a.835.835,0,0,1,.9.917c0,.989.07,7.14,0,7.143s-2.805-.615-2.87-2.5-.055-2.516-.207-2.668-2.333.117-2.966-.248A8.538,8.538,0,0,1,530.292,1837.281Z"
        transform="translate(-299.391 -1817.011)"
        strokeWidth="1"
      />
    </g>
  </svg>
    )
  return (
    <div className="  text-black dark:text-white flex flex-col items-center justify-center h-[500px] space-y-4">
     
      {/* Title outside of card */}
      <p className="text-xl font-semibold">Let’s get started</p>

      {/* Main Card */}
      <Card className="bg-[#ececec] dark:bg-[#2E2D2D] w-full max-w-[870px] h-[440px] p-3 rounded-2xl shadow-lg border-none overflow-hidden">
        
        {/* Stepper */}
    <div className="flex items-center justify-between px-24 py-3 relative w-full max-w-2xl mx-auto">
    {["Extract Data", "Generate Graph", "Start Converse"].map((step, i) => (
      <div key={step} className="flex-1 flex flex-col items-center relative">
        {i < 2 && (
          <div className="absolute top-3 left-1/2 w-full h-0.5 bg-black dark:bg-gray-600 z-0 -translate-x-0.5"></div>
        )}
       <div className={cn(
  "z-10 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-black dark:text-white",
  highlightSteps.includes(i + 1) ? "bg-purple-500" : "bg-[#d0d0d0] dark:bg-gray-600"
)}>
          {i + 1}
        </div>
        <p className="mt-2 text-sm text-black dark:text-white text-center">{step}</p>
      </div>
    ))}
  </div>

      {currentStep === 1 ? (
    
    <Tabs defaultValue="github" className="w-full">
     <div className="flex justify-center ">
    <TabsList className="grid grid-cols-4 gap-2 bg-[#e1e1e1] dark:bg-[#383838] rounded-4xl p-1">
      {[
        { value: "github", label: "GitHub", icon: Github },
        { value: "jira", label: "Jira", icon: JiraIcon },
        { value: "cicd", label: "CI/CD Tools", icon: MonitorCog },
        { value: "slack", label: "Slack", icon: Slack },
      ].map(({ value, label, icon: Icon }) => (
        <TabsTrigger
          key={value}
          value={value}
          className="flex items-center justify-center  px-4 py-1 rounded-4xl text-sm text-gray-300 
           transition-all duration-200
          data-[state=active]:bg-white dark:data-[state=active]:bg-black data-[state=active]:text-white data-[state=active]:font-semibold"
        >
          <Icon className="w-4 h-4 text-black dark:text-white" />
          <span className='text-black dark:text-white' >{label}</span>
        </TabsTrigger>
      ))}
    </TabsList>
  </div>

  

  <TabsContent value="github">
    <p className="text-xs text-black dark:text-gray-400 mb-1 px-2 text-center">
      Extract comprehensive development data using GitHub’s GraphQL API for enhanced analytics and insights.
    </p>
    <div className="grid grid-cols-1 md:grid-cols-2  text-gray-600 dark:text-gray-300 gap-4 mt-6 px-2 ">
      <div>
        <label className="block  text-sm ">GitHub Username</label>
        <Input placeholder="Enter your username" value={username} onChange={(e)=>setUsername(e.target.value)} className="bg-[#f6f6f6] dark:bg-[#2e2e2e] text-black  dark:text-white border-gray-700" />
      </div>
      <div>
        <label className="block  text-sm ">GitHub Token</label>
        <Input placeholder="Enter your token" value={token} onChange={(e)=>setToken(e.target.value)} className="bg-[#f6f6f6] dark:bg-[#2e2e2e]  text-black  dark:text-white border-gray-700" />
        <span className='text-xs mt-0.5 text-gray-400'>Required for GraphQL APl access</span>
      </div>
      <div>
        <label className="block  text-sm ">Max Pages</label>
        <Input placeholder="Eg - 10" value={maxPages} onChange={(e)=>setMaxPages(e.target.value)} className="bg-[#f6f6f6] dark:bg-[#2e2e2e]  text-black  dark:text-white border-gray-700" />
      </div>
    </div>
  </TabsContent>

  <TabsContent value="jira">
    <p className="text-xs text-black  dark:text-gray-400 px-2 text-center">Jira integration form coming soon.</p>
  </TabsContent>
  <TabsContent value="cicd">
    <p className="text-xs text-black  dark:text-gray-400 px-2 text-center">CI/CD Tools integration form coming soon.</p>
  </TabsContent>
  <TabsContent value="slack">
    <p className="text-xs text-black  dark:text-gray-400 px-2 text-center">Slack integration form coming soon.</p>
  </TabsContent>
    </Tabs>
  ) : (
    // FETCHING STATE
    <div className="flex flex-col items-center justify-center h-[70%] space-y-3 text-center">
       {getCurrentIcon()}
     
      <div>
        <p className="text-black dark:text-white font-semibold text-lg">  {loadingText === "Still processing…" ? "Still processing" + animatedDots : loadingText}
</p>
        <p className="dark:text-gray-400 text-sm mt-1">
          {loadingDescription}
        </p>
      </div>
      {progress !== 100 &&(
      <div className="w-full px-12">
        <div className="relative w-full h-1 bg-gray-600 rounded">
          <div className="absolute h-1 bg-purple-500 rounded transition-all duration-200" style={{ width: `${progress}%` }}></div>
        </div>
        
        <p className="text-xs text-black dark:text-gray-400 mt-2 text-center">{progress}%</p>
      </div>
      )}
    </div>
  )}



        {/* Navigation Buttons */}
        <div className=" flex justify-center px-2">
  {/* Left SVG button */}
  <button className="p-2 rounded-full hover:bg-gray-800" aria-label="Previous">
    <svg xmlns="http://www.w3.org/2000/svg" width="37" height="37" viewBox="0 0 44 44">
  <g id="Group_155" data-name="Group 155" transform="translate(1463 611.719) rotate(180)" opacity="0.2">
    <circle id="Ellipse_7" data-name="Ellipse 7" cx="22" cy="22" r="22" transform="translate(1419 567.719)" fill="#5a5959"/>
    <g id="bx-right-arrow-alt" transform="translate(1430.158 579.158)">
      <path id="Path_92" data-name="Path 92" d="M56.445,61.491,58.7,63.747l10.7-10.7-10.7-10.7L56.445,44.6l6.85,6.85H48v3.191H63.3Z" transform="translate(-48 -42.344)" fill="#fff"/>
    </g>
  </g>
</svg>
  </button>

  {/* Right SVG button */}
 <button
  className="p-2 rounded-full"
  aria-label="Next"


onClick={async () => {
  if (currentStep === 1) {
    if (!username || !token || !maxPages) {
      alert("❗Please fill in all fields: Username, Token, Max Pages.");
      return;
    }

    try {
      // Step 1: Health check
      const healthRes = await axios.get("http://10.73.81.34:8081/health");
      if (healthRes.data.status !== "healthy") {
        alert("🚨 Server is not up. Please try again later.");
        return;
      }
const pages = parseInt(maxPages, 10);

if (!username || !token || isNaN(pages) || pages < 1 || pages > 50) {
  alert("❗Please enter valid Username, Token, and Pages (1–50).");
  return;
}
      // Step 2: Extract call
      const extractRes = await axios.post("http://10.73.81.34:8081/extract", {
         username,
         github_token: token, // ✅ correct field name
         pages, 
      });

      const { status, extraction_id } = extractRes.data;

      if (status !== "queued" || !extraction_id) {
        alert("⚠️ Extraction not queued or ID missing.");
        return;
      }

      // Step 3: Start loading flow
      setCurrentStep(2);
      animateProgress(0, 10, 6000);
      setLoadingText("Starting the GitHub Data Extraction...");
      setLoadingDescription("We're now cloning the collective genius from your repositories.");
      // Simulated loading up to 90%
      setTimeout(() => {
        setLoadingText("Processing Raw Data...");
        setLoadingDescription("Sifting through the digital gold. We're refining raw code into pure knowledge.");
         animateProgress(10, 30, 6000); 
      }, 6000);

      setTimeout(() => {
        setLoadingText("Generating Embeddings...");
        setLoadingDescription("Translating your code into the language of AI. This is where the real magic happens.");
        animateProgress(30, 55, 6000); 
        setHighlightSteps([1, 2]);
      }, 12000);

      setTimeout(() => {
        setLoadingText("Building the Knowledge Graph...");
        setLoadingDescription("Connecting the dots. We're building your project's interactive brain.");
         animateProgress(55, 75, 6000);
        animateProgress(55, 75, 6000); 
      }, 18000);
      setTimeout(() => {
        setLoadingText("Finalizing and Preparing for Chat...");
        setLoadingDescription("The stage is set, the knowledge is mapped. Your personal code expert is ready for your questions.");
         animateProgress(76, 85, 5000); 
      }, 25000);
      // Step 4: Wait 20s, then check status
     // Final status check after 20s
setTimeout(() => {
  pollStatus(extraction_id);
}, 30000);



    } catch (error) {
      console.error("Extraction error:", error);
      alert("⚠️ Something went wrong. Please try again.");
    }

  } else if (loadingText === "Let's ask something…") {
    navigate("/velocitylens/chat");
  }
}}



>
 
  <svg xmlns="http://www.w3.org/2000/svg" width="37" height="37" viewBox="0 0 44 44">
    <g id="Group_119" data-name="Group 119" transform="translate(-1419 -567.719)">
      <circle id="Ellipse_7" data-name="Ellipse 7" cx="22" cy="22" r="22" transform="translate(1419 567.719)" fill="#b164ff"/>
      <g id="bx-right-arrow-alt" transform="translate(1430.158 579.158)">
        <path id="Path_92" data-name="Path 92" d="M56.445,61.491,58.7,63.747l10.7-10.7-10.7-10.7L56.445,44.6l6.85,6.85H48v3.191H63.3Z" transform="translate(-48 -42.344)" fill="#fff"/>
      </g>
    </g>
  </svg>
</button>

</div>

      </Card>
    </div>
  );
}
