# main.py
from fastapi import FastAPI
from pydantic import BaseModel
from typing import List
from fastapi.middleware.cors import CORSMiddleware
app = FastAPI()
origins = [
    "http://localhost:8501",  # React dev server
    "http://127.0.0.1:8501",
    # Add more origins if needed
]

# 🚪 Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,              # 👈 Allow these origins
    allow_credentials=True,
    allow_methods=["*"],                # 👈 Allow all HTTP methods
    allow_headers=["*"],                # 👈 Allow all headers
)


# In-memory list to store items
items: List[dict] = []

class Item(BaseModel):
    name: str
    email: str

@app.get("/items")
def get_items():
    return items

@app.post("/items")
def add_item(item: Item):
    items.append(item.dict())
    return {"message": "Item added", "item": item}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
