# import re

# def extract_refs(file_path):
#     extracted = []
#     with open(file_path, 'r', encoding='utf-8') as f:
#         for line in f:
#             line = line.strip()
#             # Check if line contains $ref and types.yaml
#             if '$ref:' in line and 'types.yaml' in line:
#                 # Extract the part after last '#/'
#                 match = re.search(r'#/(.+)$', line)
#                 if match:
#                     extracted.append(match.group(1))
#     return extracted

# # Example usage:
# file_path = 'C:/Users/SUKANTHAN/Desktop/AdderAPI/content.txt'  # Replace with your actual file path
# result = extract_refs(file_path)
# print("Extracted values:")
# for item in result:
#     print(item)

import re
import yaml
import os



def extract_refs(file_path):
    """Extract field names from lines containing $ref to types.yaml"""
    extracted = []
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if '$ref:' in line and 'types.yaml' in line:
                # Extract the part after the last #/
                match = re.search(r'#/(.+)$', line)
                if match:
                    field_name = match.group(1).strip()
                    extracted.append(field_name)
    return extracted

def load_types_yaml(types_yaml_path):
    """Load types.yaml and return a dict: field_name -> definition"""
    with open(types_yaml_path, 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)
    
    # In many OpenAPI-like files, components/schemas or definitions are nested
    # We'll try common locations
    schemas = data
    if 'components' in data and 'schemas' in data['components']:
        schemas = data['components']['schemas']
    elif 'definitions' in data:
        schemas = data['definitions']
    # Add more if needed...

    return schemas

def append_definitions_to_file(content_path, types_yaml_path, output_path=None):
    # Step 1: Extract referenced field names
    refs = extract_refs(content_path)
    print(f"Found {len(refs)} references: {refs}")

    # Step 2: Load types.yaml definitions
    type_definitions = load_types_yaml(types_yaml_path)

    # Step 3: Collect matching definitions
    matched_blocks = []
    missing = []

    for ref in refs:
        if ref in type_definitions:
            definition = type_definitions[ref]
            # Convert just this schema back to nicely indented YAML
            yaml_block = yaml.dump({ref: definition}, sort_keys=False, indent=2, default_flow_style=False)
            matched_blocks.append(yaml_block.rstrip())  # rstrip to avoid extra blank lines
        else:
            missing.append(ref)

    if missing:
        print(f"Warning: These fields were not found in types.yaml: {missing}")

    # Step 4: Append to the original file (or write to new file)
    output_path = output_path or content_path  # overwrite by default

    with open(content_path, 'a', encoding='utf-8') as f:  # 'a' = append mode
        f.write("\n\n# === Appended schema definitions from types.yaml ===\n\n")
        for block in matched_blocks:
            f.write(block + "\n\n")

    print(f"Successfully appended {len(matched_blocks)} schema definitions to {output_path}")

# ==============================
# Configuration - Change these paths
# ==============================
content_file = 'C:/Users/SUKANTHAN/Desktop/AdderAPI/content.txt'
types_yaml_file = 'C:/Users/SUKANTHAN/Desktop/AdderAPI/types.yaml'  # Adjust path as needed

# Optional: write to a new file instead of appending
# output_file = 'C:/Users/SUKANTHAN/Desktop/AdderAPI/content_with_schemas.txt'

append_definitions_to_file(content_file, types_yaml_file)
# append_definitions_to_file(content_file, types_yaml_file, output_file)  # uncomment to save as new file