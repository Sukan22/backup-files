'use client';
import * as React from 'react';
import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Loader2, X } from 'lucide-react';

interface ImageUploadTabProps {
  isUploadComplete: boolean;
  onGenerateUserStories: (userStories: { user_stories: any[] }) => Promise<void>;
  uploadedImageFiles?: File[] | null;
  uploadedDocFiles?: File[] | null;
  onFilesUploaded?: (images: File[] | null, docs: File[] | null) => void;
  onClearImage?: () => void;
  onClearDoc?: () => void;
}

export default function ImageUploadTab({ 
  isUploadComplete,
  onGenerateUserStories,
  uploadedImageFiles,
  uploadedDocFiles,
  onFilesUploaded,
  onClearImage,
  onClearDoc
}: ImageUploadTabProps) {
  const [isUploading, setIsUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showSuccessMessage, setShowSuccessMessage] = useState<string | null>(null);
  const [imageFiles, setImageFiles] = useState<File[]>([]);
  const [docFiles, setDocFiles] = useState<File[]>([]);
  const [isDocEnabled, setIsDocEnabled] = useState(false);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const docInputRef = useRef<HTMLInputElement>(null);

  // Helper to check if file is valid image
  const isValidImage = (file: File): boolean => {
    return file.type.startsWith('image/') && ['jpg', 'jpeg', 'png', 'svg'].some(
      ext => file.name.toLowerCase().endsWith(`.${ext}`)
    );
  };

  // Helper to check if file is valid document
  const isValidDocument = (file: File): boolean => {
    return ['.docx', '.pdf', '.xls', '.xlsx'].some(ext => 
      file.name.toLowerCase().endsWith(ext)
    );
  };

  const handleFileChange = async (type: 'image' | 'doc', event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    if (files.length === 0) return;

    if (type === 'image') {
      const validImages = files.filter(file => isValidImage(file));
      const invalidImages = files.filter(file => !isValidImage(file));

      if (invalidImages.length > 0) {
        setError(`${invalidImages.length} invalid image file(s) ignored. Please select valid image files (jpg, png, jpeg, svg).`);
      }

      if (validImages.length > 0) {
        setImageFiles(prev => [...prev, ...validImages]);
        setError(null);
      }
    } else {
      const validDocs = files.filter(file => isValidDocument(file));
      const invalidDocs = files.filter(file => !isValidDocument(file));

      if (invalidDocs.length > 0) {
        setError(`${invalidDocs.length} invalid document file(s) ignored. Please select valid document files (docx, pdf, xls, xlsx).`);
      }

      if (validDocs.length > 0) {
        setDocFiles(prev => [...prev, ...validDocs]);
        setError(null);
      }
    }
  };

  const handleClearFile = (type: 'image' | 'doc', fileIndex?: number) => {
    if (type === 'image') {
      if (fileIndex !== undefined) {
        const newFiles = imageFiles.filter((_, index) => index !== fileIndex);
        setImageFiles(newFiles);
        if (newFiles.length === 0) {
          if (imageInputRef.current) imageInputRef.current.value = '';
        }
      } else {
        setImageFiles([]);
        if (imageInputRef.current) imageInputRef.current.value = '';
        onClearImage?.();
      }
    } else {
      if (fileIndex !== undefined) {
        const newFiles = docFiles.filter((_, index) => index !== fileIndex);
        setDocFiles(newFiles);
        if (newFiles.length === 0) {
          if (docInputRef.current) docInputRef.current.value = '';
        }
      } else {
        setDocFiles([]);
        if (docInputRef.current) docInputRef.current.value = '';
        setIsDocEnabled(false);
        onClearDoc?.();
      }
    }
  };

  const handleClearAllUploadedFiles = (type: 'image' | 'doc') => {
    if (type === 'image') {
      onClearImage?.();
    } else {
      onClearDoc?.();
    }
  };

  const handleGenerateClick = async () => {
    const allImageFiles = [...(imageFiles || []), ...(uploadedImageFiles || [])];
    if (allImageFiles.length === 0) {
      setError('No image files selected.');
      return;
    }

    setIsUploading(true);
    setError(null);

    try {
      const formData = new FormData();
      
      // Append all image files
      allImageFiles.forEach((file, index) => {
        formData.append('image_files', file);
      });

      // Append document files if enabled
      const allDocFiles = isDocEnabled ? [...(docFiles || []), ...(uploadedDocFiles || [])] : [];
      allDocFiles.forEach((file, index) => {
        formData.append('reference_files', file);
      });

      const response = await fetch('http://127.0.0.1:8000/extract-and-generate', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.detail || 'Failed to generate user stories.');
      }

      const result = await response.json();
      setShowSuccessMessage(`User stories generated successfully from ${allImageFiles.length} image(s)!`);
      setTimeout(() => setShowSuccessMessage(null), 3000);

      // Update parent with uploaded files
      onFilesUploaded?.(allImageFiles, allDocFiles);

      // Clear local selected files
      setImageFiles([]);
      if (imageInputRef.current) imageInputRef.current.value = '';
      setDocFiles([]);
      if (docInputRef.current) docInputRef.current.value = '';

      await onGenerateUserStories(result);
    } catch (err) {
      console.error('Generation error:', err);
      setError(err instanceof Error ? err.message : 'Failed to generate user stories.');
    } finally {
      setIsUploading(false);
    }
  };

  const hasSelectedOrUploadedImages = (imageFiles?.length || 0) + (uploadedImageFiles?.length || 0) > 0;
  const hasSelectedOrUploadedDocs = (docFiles?.length || 0) + (uploadedDocFiles?.length || 0) > 0;

  const totalImageFiles = [...(imageFiles || []), ...(uploadedImageFiles || [])];
  const totalDocFiles = [...(docFiles || []), ...(uploadedDocFiles || [])];

  return (
    <div className="p-0 flex flex-col items-center w-full">
      {/* Outer Box */}
      <div className="w-full max-w-7xl bg-white dark:bg-[#181818] rounded-lg p-6 relative">
        {/* Upload Files Text */}
        <p className="text-black dark:text-white text-sm font-semibold">Upload </p>

        {/* Inner Box - Always Two Columns */}
        <div className="w-full bg-[#1E1F1F] dark:bg-[#1E1F1F] light:bg-white mt-[15px] border border-[#535458] dark:border-[#535458] light:border-gray-200 rounded-lg p-6 grid grid-cols-[1fr_auto_1fr] gap-4 mx-auto">
          
          {/* Image Upload Section */}
          <div className="flex flex-col gap-2">
            <p className="text-white dark:text-white light:text-black text-sm">Select Wireframe Image(s)</p>
            <div className="flex items-center gap-2">
              <input
                ref={imageInputRef}
                type="file"
                accept="image/*"
                multiple
                onChange={(e) => handleFileChange('image', e)}
                className="hidden"
                id="image-upload"
                disabled={isUploading}
              />
              <Button
                onClick={() => imageInputRef.current?.click()}
                className={`w-[10vw] bg-[#E5E5E5] dark:bg-[#E5E5E5] light:bg-white text-black dark:text-black light:text-black hover:bg-[#D0D0D0] dark:hover:bg-[#D0D0D0] light:hover:bg-gray-100 border border-[#535458] dark:border-[#535458] light:border-gray-300 rounded-md py-2 px-3 ${isUploading ? 'opacity-50 cursor-not-allowed' : ''}`}
                disabled={isUploading}
              >
                Choose Files
              </Button>
              <div className="flex items-center gap-1">
                {!hasSelectedOrUploadedImages && (
                  <p className="text-[#7C7F84] dark:text-[#7C7F84] light:text-gray-500 text-sm">No files chosen</p>
                )}
                {hasSelectedOrUploadedImages && (
                  <p className="text-[#7C7F84] dark:text-[#7C7F84] light:text-gray-500 text-sm">
                    {totalImageFiles.length} file(s) selected
                  </p>
                )}
              </div>
            </div>

            {/* Selected Files List */}
            {imageFiles.length > 0 && (
              <div className="mt-2 max-h-32 overflow-y-auto border border-[#535458] rounded-md p-2">
                {imageFiles.map((file, index) => (
                  <div key={`${file.name}-${index}`} className="flex justify-between items-center py-1 text-xs text-white">
                    <span className="truncate max-w-[150px]">{file.name}</span>
                    <Button
                      onClick={() => handleClearFile('image', index)}
                      className="p-0 bg-transparent hover:bg-transparent min-w-0 ml-2"
                      title="Clear file"
                      size="sm"
                    >
                      <X className="w-3 h-3 text-[#7C7F84]" />
                    </Button>
                  </div>
                ))}
              </div>
            )}

            {/* Uploaded Files List */}
            {isUploadComplete && uploadedImageFiles && uploadedImageFiles.length > 0 && (
              <div className="mt-2 max-h-32 overflow-y-auto border border-[#535458] rounded-md p-2">
                <div className="text-xs text-[#73787B] mb-1 font-semibold">Previously Uploaded:</div>
                {uploadedImageFiles.map((file, index) => (
                  <div key={`${file.name}-${index}`} className="flex justify-between items-center py-1 text-xs text-[#73787B]">
                    <span className="truncate max-w-[150px]">{file.name}</span>
                    <Button
                      onClick={() => handleClearAllUploadedFiles('image')}
                      className="p-0 bg-transparent hover:bg-transparent min-w-0 ml-2"
                      title="Clear all uploaded files"
                      size="sm"
                    >
                      <X className="w-3 h-3 text-[#73787B]" />
                    </Button>
                  </div>
                ))}
              </div>
            )}

            <p className="text-white dark:text-white light:text-black text-xs font-semibold">Supported format</p>
            <p className="text-white dark:text-white light:text-black text-xs">jpg, png, jpeg, svg</p>
          </div>

          {/* Divider */}
          <div className="border-l border-[#535458] dark:border-[#535458] light:border-gray-200"></div>

          {/* Document Upload Section */}
          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-2">
              <Checkbox
                id="doc-checkbox"
                checked={isDocEnabled}
                onCheckedChange={(checked) => setIsDocEnabled(checked as boolean)}
              />
              <label htmlFor="doc-checkbox" className="text-white dark:text-white light:text-black text-sm">
                Select Reference Document(s) (Optional)
              </label>
            </div>
            <div className="flex items-center gap-2">
              <input
                ref={docInputRef}
                type="file"
                accept=".docx,.pdf,.xls,.xlsx"
                multiple
                onChange={(e) => handleFileChange('doc', e)}
                className="hidden"
                id="doc-upload"
                disabled={isUploading || !isDocEnabled}
              />
              <Button
                onClick={() => docInputRef.current?.click()}
                className={`w-[10vw] bg-[#E5E5E5] dark:bg-[#E5E5E5] light:bg-white text-black dark:text-black light:text-black hover:bg-[#D0D0D0] dark:hover:bg-[#D0D0D0] light:hover:bg-gray-100 border border-[#535458] dark:border-[#535458] light:border-gray-300 rounded-md py-2 px-3 ${(isUploading || !isDocEnabled) ? 'opacity-50 cursor-not-allowed' : ''}`}
                disabled={isUploading || !isDocEnabled}
              >
                Choose Files
              </Button>
              <div className="flex items-center gap-1">
                {!hasSelectedOrUploadedDocs && (
                  <p className="text-[#7C7F84] dark:text-[#7C7F84] light:text-gray-500 text-sm">No files chosen</p>
                )}
                {hasSelectedOrUploadedDocs && (
                  <p className="text-[#7C7F84] dark:text-[#7C7F84] light:text-gray-500 text-sm">
                    {totalDocFiles.length} file(s) selected
                  </p>
                )}
              </div>
            </div>

            {/* Selected Files List */}
            {docFiles.length > 0 && (
              <div className="mt-2 max-h-32 overflow-y-auto border border-[#535458] rounded-md p-2">
                {docFiles.map((file, index) => (
                  <div key={`${file.name}-${index}`} className="flex justify-between items-center py-1 text-xs text-white">
                    <span className="truncate max-w-[150px]">{file.name}</span>
                    <Button
                      onClick={() => handleClearFile('doc', index)}
                      className="p-0 bg-transparent hover:bg-transparent min-w-0 ml-2"
                      title="Clear file"
                      size="sm"
                    >
                      <X className="w-3 h-3 text-[#7C7F84]" />
                    </Button>
                  </div>
                ))}
              </div>
            )}

            {/* Uploaded Files List */}
            {isUploadComplete && uploadedDocFiles && uploadedDocFiles.length > 0 && (
              <div className="mt-2 max-h-32 overflow-y-auto border border-[#535458] rounded-md p-2">
                <div className="text-xs text-[#73787B] mb-1 font-semibold">Previously Uploaded:</div>
                {uploadedDocFiles.map((file, index) => (
                  <div key={`${file.name}-${index}`} className="flex justify-between items-center py-1 text-xs text-[#73787B]">
                    <span className="truncate max-w-[150px]">{file.name}</span>
                    <Button
                      onClick={() => handleClearAllUploadedFiles('doc')}
                      className="p-0 bg-transparent hover:bg-transparent min-w-0 ml-2"
                      title="Clear all uploaded files"
                      size="sm"
                    >
                      <X className="w-3 h-3 text-[#73787B]" />
                    </Button>
                  </div>
                ))}
              </div>
            )}

            <p className="text-white dark:text-white light:text-black text-xs font-semibold">Supported format</p>
            <p className="text-white dark:text-white light:text-black text-xs">docx, pdf, xls, xlsx</p>
          </div>
        </div>

        {/* Bottom Buttons */}
        <div className="flex justify-start mt-6 w-full max-w-4xl">
          <Button
            onClick={handleGenerateClick}
            disabled={!hasSelectedOrUploadedImages || isUploading}
            className={`bg-[#1E1F1F] dark:bg-[#1E1F1F] light:bg-white text-[#DBDBDB] dark:text-[#DBDBDB] light:text-black border border-[#535458] dark:border-[#535458] light:border-gray-300 rounded-md hover:bg-[#E5E5E5] dark:hover:bg-[#E5E5E5] light:hover:bg-gray-50 hover:text-black dark:hover:text-black light:hover:text-black transition-colors ${(!hasSelectedOrUploadedImages || isUploading) ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            {isUploading ? (
              <span className="flex items-center">
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
                Generating Stories...
              </span>
            ) : (
              `Generate User Stories (${totalImageFiles.length} image${totalImageFiles.length !== 1 ? 's' : ''})`
            )}
          </Button>
        </div>

        {/* Messages */}
        {error && <p className="text-red-500 dark:text-red-400 mt-4">Error: {error}</p>}
        {showSuccessMessage && (
          <p className="text-green-600 dark:text-green-400 mt-4 animate-pulse">{showSuccessMessage}</p>
        )}
      </div>
    </div>
  );
}