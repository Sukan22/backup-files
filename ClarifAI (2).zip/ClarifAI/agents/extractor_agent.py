# agents/extractor_agent.py
import re
import sys
import os

from google.adk.agents import Agent
from google.adk.tools import FunctionTool
from tools.extractor_tools import load_docx_tool, extract_requirements_tool, load_document_tool
from typing import List, Dict, Callable

# class ExtractorAgent(Agent):
#     def __init__(self, llm_caller: Callable[[str], str]):
#         super().__init__(name="ExtractorAgent", description="Extracts requirements from a BRD (.docx)")

#         self._llm_caller = llm_caller

#         """ # Save function references for internal use
#         self._load_docx = load_docx_tool
#         self._extract_reqs = extract_requirements_tool

#         # Register tools
#         self.tools.append(FunctionTool(func=load_docx_tool))
#         self.tools.append(FunctionTool(func=extract_requirements_tool)) """

#     def run(self, file_path: str):
#         result = load_docx_tool({"file_path": file_path})
#         reqs = extract_requirements_tool({"raw_text": result["raw_text"]}, self._llm_caller)
#         return reqs["requirements"]


class ExtractorAgent(Agent):
    def __init__(self, llm_caller: Callable[[str], str]):
        super().__init__(name="ExtractorAgent", description="Extracts requirements from a BRD (.docx or .pdf)")
        self._llm_caller = llm_caller

    def run(self, file_path: str):
        result = load_document_tool({"file_path": file_path})
        reqs = extract_requirements_tool({"raw_text": result["raw_text"]}, self._llm_caller)
        return reqs["requirements"]
