# agents/classifier_agent.py
import logging
from google.adk import Agent
from google.adk.tools import FunctionTool
from tools.classifier_tools import classify_requirement_tool
from typing import List, Dict, Callable
from utils.logger import get_logger
import json

class ClassifierAgent(Agent):
    def __init__(self, llm_caller: Callable[[str], str], verbose=False):
        super().__init__(
            name="ClassifierAgent",
            description="Classifies extracted requirements using Gemini."
        )
        
        self._llm_caller = llm_caller
        """ self._logger = get_logger(
            log_to_console=False,
            log_to_file=True,
            level=logging.DEBUG if verbose else logging.INFO
        ) """

        """ # Wrap and bind Gemini-aware tool
        def classify_with_llm(inputs: Dict, verbose=False) -> Dict:
            return classify_requirement_tool(inputs, self._llm_caller, verbose)

        self._classify_func = classify_with_llm  # for internal use

        # Register tools
        self.tools.append(FunctionTool(func=classify_with_llm)) """

    def run(self, extracted_requirements: List[Dict]) -> List[Dict]:
        # self._logger.info(f"[{self.name}] Received {len(extracted_requirements)} requirements for classification.")

        extracted_requirements = classify_requirement_tool(extracted_requirements, self._llm_caller, verbose=False)
        return extracted_requirements