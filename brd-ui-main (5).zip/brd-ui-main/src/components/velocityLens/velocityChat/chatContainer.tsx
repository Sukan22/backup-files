"use client";
import { useState, useEffect,type SetStateAction } from "react";
import VelocityChat from "./vchat";
import { ChatTopbar } from "./chatHeaders";
//import type { ChatItem } from "./ChatHistoryPopup";
import ChatHistoryPopup from "./ChatHistoryPopup";
import  {SearchChatPopup}  from "./SearchChatPopup";
import { v4 as uuidv4 } from "uuid";
export interface ChatItem {
  question: string;
  answer: string | React.ReactElement;
}

export interface ChatSession {
  id: string;
  chats: ChatItem[];
  createdAt: string;
}
export default function ChatPage() {

const [activeSessionId, setActiveSessionId] = useState<string>(() => {
  const newId = uuidv4();
  return newId;
}); 
const [chatSessions, setChatSessions] = useState<ChatSession[]>([{
  id: activeSessionId,
  chats: [],
  createdAt: new Date().toISOString(),
}]); //const [chatHistory, setChatHistory] = useState<ChatItem[]>([]);
  const [activePopup, setActivePopup] = useState<string | null>(null);
    const [resetSignal, setResetSignal] = useState(0);
   const [recentSearches,setRecentSearches]=useState<string[]>([]);
   const activeChat = chatSessions.find(s => s.id === activeSessionId);
const chatHistory = activeChat?.chats || [];
useEffect(() => {
  if (chatSessions.length === 0) {
    const newId = uuidv4();
    const newSession: ChatSession = {
      id: newId,
      chats: [],
      createdAt: new Date().toISOString(),
    };
    setChatSessions([newSession]);
    setActiveSessionId(newId);
    setResetSignal(prev => prev + 1);
  }
}, [chatSessions.length]);
 const handleTriggerPopup = (popup: string) => {
  setActivePopup(popup);

  if (popup === "new") {
    const newSession: ChatSession = {
      id: uuidv4(),
      chats: [],
      createdAt: new Date().toISOString(),
    };
    setChatSessions(prev => [...prev, newSession]);
    setActiveSessionId(newSession.id);
    setResetSignal(prev => prev + 1);
  }
};

const updateActiveChat: React.Dispatch<React.SetStateAction<ChatItem[]>> = (updateFnOrValue) => {
  setChatSessions(prev =>
    prev.map(session =>
      session.id === activeSessionId
        ? {
            ...session,
          chats: typeof updateFnOrValue === 'function'
              ? (updateFnOrValue as (prev: ChatItem[]) => ChatItem[])(session.chats)
              : updateFnOrValue,
          }
        : session
    )
  );
};

  const handleClosePopup = () => {
    setActivePopup(null);
  };

  const handleDeleteChat = (index: number) => {
  const updated = [...chatHistory];
  updated.splice(index, 1);
  updateActiveChat(updated);
};
const handleDeleteSession = (sessionId: string) => {
  setChatSessions(prev => prev.filter(s => s.id !== sessionId));
  if (sessionId === activeSessionId) {
    setActiveSessionId('');
  }
};

const handleSelectSession = (sessionId: string) => {
  setActiveSessionId(sessionId);
  //setResetSignal(prev => prev + 1);
};
  return (
    <div className="relative">
      {/* <ChatTopbar onTriggerPopup={handleTriggerPopup} />

 
  <VelocityChat
    chatHistory={chatHistory}
    setChatHistory={updateActiveChat}
    resetSignal={resetSignal}
    showSearchModal={false}
    setShowSearchModal={() => {}}
  /> */}


{/* {activePopup === "history" && (
  <ChatHistoryPopup
    sessions={chatSessions}
    onClose={handleClosePopup}
    onDelete={handleDeleteSession}
    onSelect={handleSelectSession}
  />
)} */}


     {/* <SearchChatPopup
        open={activePopup === "search"}
        onClose={handleClosePopup}
        chatHistory={chatHistory} recentSearches={recentSearches} setRecentSearches= {setRecentSearches}/> */}

    </div>
  );
}
