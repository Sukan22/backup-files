# # tools/extractor_tools.py
# from typing import Dict, List
# import docx

# from tools.prompt_utils import extract_clean_json

# def load_docx_tool(inputs: Dict) -> Dict:
#     """
#     Loads a .docx file and returns its raw text.
#     """
#     file_path = inputs["file_path"]
#     doc = docx.Document(file_path)
#     text = "\n".join([p.text for p in doc.paragraphs if p.text.strip()])
#     return {"raw_text": text}


# def extract_requirements_tool(inputs: Dict, run_llm, verbose=False) -> Dict:
#     """
#     Extracts requirement-like statements from raw text.
#     """

#     """ Requirement Extraction through simple method
#     raw_text = inputs["raw_text"]
#     paragraphs = [p.strip() for p in raw_text.split("\n") if p.strip()]
#     requirements = []

#     for idx, para in enumerate(paragraphs):
#         if any(k in para.lower() for k in ["must", "shall", "should", "will", "ability to"]):
#             requirements.append({
#                 "requirement_id": f"REQ-{idx + 1:03d}",
#                 "requirement_text": para
#             })

#     return {"requirements": requirements} 
#     """

#     # Requirement Extraction through prompt
#     # Step 1: First get the requirement text in whole
#     raw_text = inputs["raw_text"]

#     # Step 3: Build the prompt
#     prompt = f"""
#         You are a business analyst reading a Business Requirements Document (BRD).

#         Extract all the business requirements from the following text. For each requirement, return:

#         - requirement_id: a unique ID (e.g., REQ-001, REQ-002...)
#         - requirement_text: clear, concise statement of the requirement

#         Only return a JSON list of requirements.

#         Do not include code or markdown. Do not explain.

#         Return a JSON array in this exact format:
#         [
#             {{
#                 "requirement_id": "REQ-001",
#                 "requirement_text": "Text of the extracted requirement"
#             }},
#             ...
#         ]

#         IMPORTANT:
#         - Do NOT use Markdown or triple backticks.
#         - Do NOT add explanations.
#         - Respond only with a raw JSON object (no markdown, no ```json fences, no explanation).

#         BRD Content:
#         ```{raw_text}```
#     """.strip()

#     # log the prompt
#     # tool_logger.debug("[ClassifyRequirementTool] Requirements that need classification:\n" + prompt)

#     response = run_llm(prompt)
#     # tool_logger.debug("[ClassifyRequirementTool] LLM raw response:\n" + response)

#     try:
#         # llm_results = json.loads(response)
#         llm_results = extract_clean_json(response)
#     except Exception as e:
#         # tool_logger.error(f"[ClassifyRequirementTool] Failed to parse LLM response: {e}")
#         llm_results = []

#     return {"requirements": llm_results}

#########################################################################################################


from typing import Dict, List
import docx

from tools.prompt_utils import extract_clean_json
import pdfplumber
import os

def load_pdf_tool(inputs: Dict) -> Dict:
    """
    Loads a PDF file and returns its text with page and line numbers.
    """
    file_path = inputs["file_path"]
    paragraphs = []

    with pdfplumber.open(file_path) as pdf:
        for page_num, page in enumerate(pdf.pages, start=1):
            text = page.extract_text()
            if not text:
                continue
            lines = text.split('\n')
            for line_num, line in enumerate(lines, start=1):
                if line.strip():
                    paragraphs.append({
                        "page_number": page_num,
                        "line_number": line_num,
                        "text": line.strip()
                    })

    return {"raw_text": paragraphs}


def load_docx_tool(inputs: Dict) -> Dict:
    """
    Loads a .docx file and returns a list of paragraphs with line numbers.
    Output format: {"raw_text": [{"line_number": ..., "text": ...}, ...]}
    """
    file_path = inputs["file_path"]
    doc = docx.Document(file_path)

    paragraphs = []
    for idx, p in enumerate(doc.paragraphs):
        if p.text.strip():
            paragraphs.append({
                 "page_number": None,
                "line_number": idx + 1,
                "text": p.text.strip()
            })

    return {"raw_text": paragraphs}

def load_document_tool(inputs: Dict) -> Dict:
    file_path = inputs["file_path"]
    ext = os.path.splitext(file_path)[-1].lower()

    if ext == ".docx":
        return load_docx_tool(inputs)
    elif ext == ".pdf":
        return load_pdf_tool(inputs)
    else:
        raise ValueError(f"Unsupported file type: {ext}")
        


def extract_requirements_tool(inputs: Dict, run_llm, verbose=False) -> Dict:
    """
    Extracts requirement-like statements using LLM from line-numbered paragraphs in 'raw_text'.
    """
    raw_paragraphs = inputs["raw_text"]  # <- key name remains 'raw_text'

    # formatted_text = "\n".join([
    #     f"Line {p['line_number']}: {p['text']}" for p in raw_paragraphs
    # ])
    formatted_text = "\n".join([
    f"Page {p['page_number'] if p['page_number'] is not None else 'N/A'}, Line {p['line_number']}: {p['text']}"
    for p in raw_paragraphs
])

    prompt = f"""
You are an experienced Business Analyst reading a Business Requirements Document (BRD).
Your task is to extract all statements that appear to be business requirements, including incomplete ones.

Follow these rules strictly:

Step 1 — Identify Sections

⦁	Detect section headings and numbering (e.g., "1. Introduction", "2. Functional Requirements", "2.1 Payment Processing").
⦁	If a heading is not numbered but appears in bold, all caps, or is clearly a section title, treat it as a section heading.
⦁	If a line is a heading, remember it as current_section until a new heading appears.
⦁	Assign source_section for each requirement as the most recent heading above it.

Step 2 — Identify Business Requirements

A requirement is any statement that describes a capability, feature, rule, or condition that the business, system, or process should fulfill — even if it’s incomplete.

Include:
⦁	Clear requirements
⦁	Partially stated requirements (e.g., “The system must allow user authentication”)
⦁	Implied requirements only when a capability is a direct and necessary prerequisite for another explicitly stated requirement to function. For example, if a requirement is 'The user shall reset their password via an email link', an implied requirement is 'The system shall send a password reset link to the user's registered email address'. Avoid inferring requirements from general background descriptions.

Exclude:
⦁	Explanations, background info, or context
⦁	Technical implementation details (unless explicitly required by the business)
⦁	Assumptions, constraints, and notes unless clearly stated as a requirement

Step 3 — Splitting Logic

A single sentence may contain multiple, distinct requirements. Split a sentence into separate atomic requirements only if each resulting part describes a capability that can be independently implemented and tested.

Splitting Rules:
Split when:
⦁	The sentence uses conjunctions like "and," "or," or commas to connect discrete actions, functions, or behaviors.
⦁	Each clause describes a distinct, verifiable action, such as "create," "read," "update," or "delete."
⦁	The actions can be independently developed, implemented, or tested.

Do Not Split when:
⦁	The sentence expresses a high-level goal, strategic objective, or a quality attribute (e.g., scalability, reliability, maintainability).
⦁	Splitting the sentence would fragment its core meaning or make the individual parts less clear.

Examples:
Split These:
Input: “The system shall validate user input and store it in the database.”
Output:
“System shall validate user input.”
“System shall store validated input in the database.”

Do Not Split These:
Input: “The platform must meet both essential and requested features.”
Output:
“Platform must meet both essential and requested features.”
Input: “The goal is to ensure scalability, reliability, and maintainability of the system.”
Output:
“Goal is to ensure scalability, reliability, and maintainability of the system.”

Step 4 — Output Format

Only return a JSON array like:
    [
        {{
            "requirement_id": "REQ-001",
            "requirement_text": "Rewritten version of the requirement, clear and concise",
            "original_text": "Exact original sentence from the document",
            "line_number": 15 (the line number from which the requirement came (visible in input as "Line X:")),
            "page_number": null (use the actual page number if available, otherwise set to null),
            "source_section": "2. Functional Requirements (section number or heading if identifiable or use the previous section heading until another heading or numbered section is found)"
        }},
        ...
    ]

The 'requirement_id' should be a unique, sequentially generated string for each requirement extracted in a single request, starting with 'REQ-001', then 'REQ-002', and so on.

Step 5 — Rewriting Rules

⦁	Keep meaning intact, but remove redundancy and jargon.
⦁	If the original sentence contains multiple requirements, Apply the splitting logic from Step 3 where appropriate.
⦁	If a requirement is clear, rewrite it in a concise, active voice statement, preferably following the format: 'The [System/User/Actor] shall [action/capability]'. For example, rewrite 'The downloading of reports by users should be possible' to 'The user shall be able to download reports'.
⦁	If vague → preserve vagueness but optionally add a bracketed note, e.g., "System should be fast [performance metric not defined]".
⦁	Do not omit vague requirements.

Step 6 — Page Numbers
⦁	If the actual page number is available, include it.
⦁	Otherwise, set "page_number": null.

IMPORTANT:

⦁	Do NOT use Markdown or triple backticks.
⦁	
⦁	Do NOT add explanations.
⦁	
⦁	Return only the raw JSON array.

Text to analyze (BRD):
{formatted_text}

""".strip()
#     prompt = f"""
# You are a business analyst reading a Business Requirements Document (BRD).

# Extract all business requirements from the following text. For each requirement, return:

# - requirement_id: a unique ID (e.g., REQ-001, REQ-002...)
# - requirement_text: a rewritten version of the requirement
# - original_text: the full original sentence
# - line_number: the line number from which the requirement came (visible in input as "Line X:")
# - page_number: use the actual page number if available, otherwise set to null
# - source_section: section number or heading if identifiable or use the previous section heading until another heading or numbered section is found

# Only return a JSON array like:
# [
#     {{
#         "requirement_id": "REQ-001",
#         "requirement_text": "System shall allow password reset via email.",
#         "original_text": "Users must be able to reset their password through a link sent by email.",
#         "line_number": 45,
#         "page_number": 1,
#         "source_section": "3.2.1"
#     }},
#     ...
# ]

# IMPORTANT:
# - Do NOT use Markdown or triple backticks.
# - Do NOT add explanations.
# - Return only the raw JSON array.

# Text to analyze:
# {formatted_text}
# """.strip()

    response = run_llm(prompt)

    try:
        llm_results = extract_clean_json(response)
    except Exception as e:
        if verbose:
            print(f"[extract_requirements_tool] Failed to parse response: {e}")
        llm_results = []

    return {"requirements": llm_results}