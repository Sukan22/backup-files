import streamlit as st
from typing import List
from pydantic import BaseModel

# Page configuration
st.set_page_config(
    page_title="Items Manager",
    page_icon="📋",
    layout="centered",
    initial_sidebar_state="expanded"
)

# Item model
class Item(BaseModel):
    name: str
    email: str

# In-memory list to store items
if "items_list" not in st.session_state:
    st.session_state.items_list = []

st.title("📋 Items Manager")
st.markdown("Manage your items with ease using this simple interface")

# Create tabs for different operations
tab1, tab2 = st.tabs(["Add Item", "View Items"])

# TAB 1: Add Item
with tab1:
    st.subheader("➕ Add New Item")
    
    with st.form("add_item_form"):
        name = st.text_input("Item Name", placeholder="Enter item name")
        email = st.text_input("Email", placeholder="Enter email address")
        
        submitted = st.form_submit_button("Add Item", use_container_width=True)
        
        if submitted:
            if name and email:
                # Add item directly to session state
                new_item = {"name": name, "email": email}
                st.session_state.items_list.append(new_item)
                st.success("✅ Item added successfully!")
                st.balloons()
            else:
                st.warning("⚠️ Please fill in all fields")

# TAB 2: View Items
with tab2:
    st.subheader("📂 All Items")
    
    if st.button("🔄 Refresh Items", use_container_width=True):
        st.rerun()
    
    items = st.session_state.items_list
    
    if items:
        st.success(f"Found {len(items)} item(s)")
        
        # Display items in a formatted table
        for idx, item in enumerate(items, 1):
            with st.container(border=True):
                col1, col2, col3 = st.columns([2, 2, 1])
                with col1:
                    st.markdown(f"**Name:** {item.get('name', 'N/A')}")
                with col2:
                    st.markdown(f"**Email:** {item.get('email', 'N/A')}")
                with col3:
                    if st.button("🗑️ Delete", key=f"delete_{idx}"):
                        st.session_state.items_list.pop(idx - 1)
                        st.rerun()
    else:
        st.info("📭 No items found. Add some items to get started!")

# Sidebar - Info
with st.sidebar:
    st.markdown("---")
    st.subheader("📊 Statistics")
    
    total_items = len(st.session_state.items_list)
    st.metric("Total Items", total_items)
    
    st.markdown("---")
    st.markdown(
        """
        ### How to Use
        1. Go to **Add Item** tab
        2. Enter the item name and email
        3. Click **Add Item** button
        4. Go to **View Items** tab to see all items
        5. Delete items using the delete button
        """
    )
    
    st.markdown("---")
    st.info("💾 Data is stored in session and will be lost on page refresh.")
