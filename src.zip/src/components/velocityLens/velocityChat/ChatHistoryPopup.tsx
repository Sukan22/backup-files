"use client";

import { DeleteIcon, Trash, X } from "lucide-react";
import { History } from "lucide-react";
import type { ChatSession } from "./chatContainer";
export interface ChatItem {
  question: string;
  answer: string | React.ReactElement;
}

interface ChatHistorySidebarProps {
  sessions: ChatSession[];
  onClose: () => void;
  onDelete: (sessionId: string) => void;
  onSelect: (sessionId: string) => void;
}

export default function ChatHistoryPopup({
  sessions,
  onClose,
  onDelete,
  onSelect,
}: ChatHistorySidebarProps) {
const nonEmptySessions = sessions.filter(session => session.chats.length > 0);
  return (
    <aside className="fixed top-0 right-0 z-50 h-[100vh] w-70  bg-[#f3f3f3] dark:bg-[#0D0D0D] border border-black dark:border-[#3e3e3e] flex flex-col rounded-[10px]">
      <header className="flex items-center py-3 border-b border-[#3e3e3e]">
        <History size={"17px"} className="ml-2"/>
        <h3 className="text-sm font-semibold text-black dark:text-white ml-2">Chat History</h3>
        <button onClick={onClose} aria-label="Close" style={{cursor:"pointer",marginLeft:"110px"}}>
          <X className="w-5 h-5 text-black dark:text-white" />
        </button>
      </header>

      <div className="flex-1 overflow-y-auto space-y-2 px-2 pb-4 mt-2">
       {nonEmptySessions.length === 0 ? (
  <p className="text-muted-foreground text-center py-4">No questions yet</p>
) : (
  nonEmptySessions.map((session) => (
    <div
      key={session.id}
      className="flex justify-between items-center text-sm  text-black dark:text-gray-300 bg-white dark:bg-[#3e3e3e] p-2 rounded-lg hover:bg-[#b1afaf] transition-colors cursor-pointer"
      onClick={() => onSelect(session.id)}
    >
      <p className="truncate w-[85%]" title={session.chats[0]?.question ?? "No question yet"}>
        {session.chats[0]?.question ?? "No question yet"}
      </p>
      <button
        onClick={(e) => {
          e.stopPropagation(); // prevent session open on delete
          onDelete(session.id);
        }}
        className="text-black dark:text-gray-400 hover:text-red-500"
      >
        <Trash className="w-4 h-4" />
      </button>
    </div>
  ))
)}

      </div>
      <footer className="flex justify-center items-center py-2 w-full">
        <button
          onClick={onClose}
          className="w-full h-8 ml-2 mr-2 bg-[#ececec] dark:bg-[#1a1a1a] text-black dark:text-white rounded-lg hover:bg-[#8f8f8f] border border-[#3e3e3e]"
        >
          Close
        </button>
        </footer>
    </aside>
  );
}
