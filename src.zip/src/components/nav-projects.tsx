

// import {
//   DropdownMenu,
//   DropdownMenuContent,
//   DropdownMenuItem,
//   DropdownMenuSeparator,
//   DropdownMenuTrigger,
// } from "@/components/ui/dropdown-menu"
import { useNavigate } from "react-router-dom";
import {
  SidebarGroup,
  SidebarGroupLabel,
  SidebarMenu,
  //SidebarMenuAction,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar"
import { cn } from "@/lib/utils"
import { slugify } from "@/lib/slugify";
import { useState } from "react";
import { ChevronDown, ChevronRight } from "lucide-react";
interface NavProjectsProps {
  projects: {
    name: string;
    icon: React.ComponentType<React.SVGProps<SVGSVGElement>>;
    isActive?: boolean;

    children?: {
      title: string;
      id: string;
    }[];
  }[];
  onSelect: (name: string) => void;
  activePage: string;
}

export function NavProjects({
  projects,
  onSelect,
  activePage
}: NavProjectsProps) {
 //const { isMobile } = useSidebar();
  const navigate = useNavigate();
  const [expanded, setExpanded] = useState<string | null>(null);

  return (
    <SidebarGroup className="group-data-[collapsible=icon]:hidden">
      <SidebarGroupLabel>Modules</SidebarGroupLabel>
      <SidebarMenu>
        {projects.map((item) => {
          const hasChildren = !!item.children?.length ;
          const isExpanded = expanded === item.name;

          return (
            <SidebarMenuItem key={item.name}>
              <SidebarMenuButton
                onClick={() => {
                  if (hasChildren) {
                    setExpanded(isExpanded ? null : item.name);
                  } else {
                    onSelect(item.name);
                    navigate(`/${slugify(item.name)}`);
                  }
                }}
                className={cn(
                  "flex items-center gap-3 justify-between",
                item.name === activePage || item.children?.some((child) => child.id === activePage)

                    ? "text-purple-500 font-semibold hover:text-purple-500"
                    : "text-black dark:text-white hover:bg-accent"
                )}
              >
                <span className="flex items-center gap-2">
                  <item.icon
                    className={cn(
                      "!w-[35px] !h-[35px]",
                item.name === activePage || item.children?.some((child) => child.id === activePage)
                        ? "text-purple-500"
                        : "text-gray-900 dark:text-white"
                    )}
                  />
                  {item.name}
                </span>
                {/*  */}
              </SidebarMenuButton>

              {hasChildren && isExpanded && (
                  <div className="relative ml-10 mt-1 space-y-1">
    {/* Vertical line */}
    <div className="absolute left-[-18px] top-0 h-full w-[2px] bg-black dark:bg-gray-600" />

                  {item.children?.map((child) => (
                    <SidebarMenuButton
                      key={child.id}
                      onClick={() => {
                        onSelect(child.id);
                        navigate(`/${slugify(child.id)}`);
                      }}
                    className={cn(
  "block text-sm w-full text-left px-2 py-1 rounded-md",
  activePage === child.id
    ? "text-purple-400 font-semibold hover:text-purple-400"
    : "text-black dark:text-white hover:bg-accent"
)}

                    >
                      {child.title}
                    </SidebarMenuButton>
                  ))}
                </div>
              )}
            </SidebarMenuItem>
          );
        })}
      </SidebarMenu>
    </SidebarGroup>
  );
}
