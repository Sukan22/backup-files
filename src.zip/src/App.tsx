import React from "react"
import { ThemeProvider } from "@/components/theme-provider"
import { BrowserRouter, Routes, Route } from "react-router-dom"
import LandingPage from "@/components/LandingPage"
import Page from "@/dashboard/Page"
import VelocityChat from "./components/velocityLens/velocityChat/vchat"
import "@/App.css"


import LoginPage from "./components/login-page"
import Clarifai from "./components/clarifai/Clarifai"
import VelocityLens from "./components/velocityLens/velocityHome"
import ChatContainer from "./components/velocityLens/velocityChat/chatContainer"

function App() {
  return (
    <ThemeProvider defaultTheme="dark" storageKey="vite-ui-theme">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Page />}>
          <Route index element={<div>Select a project</div>} />
          <Route path="clarifai" element={<Clarifai />} />
          <Route path="velocitylens" element={<VelocityLens />} />
          <Route path="velocitylens/chat" element={<ChatContainer />} />

          {/* Add other nested routes similarly */}
        </Route>
          {/* <Route path="/" element={<LandingPage/>} /> */}
          <Route path="/" element={<LoginPage />} />
          <Route path="/Landing" element={<LandingPage/>}/>
          {/* <Route path="/product/code-sensei" element={<Sensei />} /> */}
           <Route path="/:tool" element={<Page />} />
           <Route path="velocitylens/chat" element={<ChatContainer />} />


        </Routes>
      </BrowserRouter>
    </ThemeProvider>
  )
}

export default App