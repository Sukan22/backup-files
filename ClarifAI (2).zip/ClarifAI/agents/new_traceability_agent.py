from typing import List, Dict
import logging

logger = logging.getLogger("RequirementAI")

class NewTraceabilityAgent:
    def run(self, inputs: Dict) -> Dict:
        """
        Build a traceability matrix keyed by user_story_id (no requirement layer).
        Expected inputs:
        {
            "user_stories": [
                {"user_story_id": "...", "usid": "...", "user_story": "...", "acceptance_criteria": [...]}
            ],
            "gherkin_scenarios": [
                {"user_story_id": "...", "feature": "...", "scenarios": [...]}
            ],
            "test_cases": [
                {"user_story_id": "...", "test_case_id": "...", ...}
            ]
        }
        """
        user_stories = {us["user_story_id"]: us for us in inputs.get("user_stories", [])}
        gherkin = {g["user_story_id"]: g for g in inputs.get("gherkin_scenarios", [])}
        test_cases = inputs.get("test_cases", [])

        # --- Index test cases by user_story_id ---
        tc_map: Dict[str, List[Dict]] = {}
        for tc in test_cases:
            uid = tc.get("user_story_id")
            if uid:
                tc_map.setdefault(uid, []).append(tc)

        all_ids = sorted(set(
            list(user_stories.keys())
            + list(gherkin.keys())
            + [tc.get("user_story_id") for tc in test_cases if "user_story_id" in tc]
        ))

        logger.info(f"Building traceability matrix for {len(all_ids)} user stories.")

        traceability = []

        for uid in all_ids:
            us_data = user_stories.get(uid, {})
            gherkin_data = gherkin.get(uid, {})

            trace = {
                "user_story_id": uid,
                "usid": us_data.get("usid", ""),
                "user_story": us_data.get("user_story", ""),
                "acceptance_criteria": us_data.get("acceptance_criteria", []),
                "gherkin_feature": gherkin_data.get("feature", ""),
                "gherkin_scenarios": gherkin_data.get("scenarios", []),
                "test_cases": tc_map.get(uid, [])
            }

            traceability.append(trace)

        return {"traceability": traceability}
