import os
import io
import docx
import fitz  # PyMuPDF
import pytesseract
from PIL import Image

def extract_text_from_file(file_path: str) -> str:
    ext = os.path.splitext(file_path)[1].lower()
    if ext == ".pdf":
        return _extract_pdf(file_path)
    elif ext == ".docx":
        return _extract_docx(file_path)
    else:
        raise ValueError(f"Unsupported file type: {ext}")

def _extract_pdf(path: str) -> str:
    text_parts = []
    with fitz.open(path) as doc:
        for page in doc:
            text_parts.append(page.get_text())
    return "\n".join(text_parts)

def _extract_docx(path: str) -> str:
    doc = docx.Document(path)
    return "\n".join([para.text for para in doc.paragraphs])

# -------------------------
# NEW: Table extraction
# -------------------------
def extract_tables_from_file(file_path: str):
    """
    Extract tables from PDF or DOCX and return as list of strings.
    """
    ext = os.path.splitext(file_path)[1].lower()
    tables_text = []

    if ext == ".pdf":
        with fitz.open(file_path) as doc:
            for page in doc:
                tables = page.find_tables()
                if tables:
                    for table in tables:
                        # Convert table to CSV-like text
                        table_str = "\n".join([", ".join(row) for row in table.extract() if row])
                        tables_text.append(table_str)

    elif ext == ".docx":
        doc = docx.Document(file_path)
        for table in doc.tables:
            rows = []
            for row in table.rows:
                cells = [cell.text.strip() for cell in row.cells]
                rows.append(", ".join(cells))
            tables_text.append("\n".join(rows))

    return tables_text

# -------------------------
# NEW: Image extraction + OCR
# -------------------------
def extract_images_from_file(file_path: str):
    """
    Extract images from PDF or image files and return OCR text descriptions.
    """
    ext = os.path.splitext(file_path)[1].lower()
    image_texts = []

    if ext == ".pdf":
        with fitz.open(file_path) as doc:
            for page_index, page in enumerate(doc):
                for img_index, img in enumerate(page.get_images(full=True)):
                    xref = img[0]
                    base_image = doc.extract_image(xref)
                    image_bytes = base_image["image"]
                    pil_img = Image.open(io.BytesIO(image_bytes))
                    text = pytesseract.image_to_string(pil_img)
                    if text.strip():
                        image_texts.append(text.strip())

    elif ext in (".png", ".jpg", ".jpeg"):
        pil_img = Image.open(file_path)
        text = pytesseract.image_to_string(pil_img)
        if text.strip():
            image_texts.append(text.strip())

    return image_texts