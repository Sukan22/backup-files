import requests
from requests.auth import HTTPBasicAuth
import json

JIRA_URL = "https://rajatjana.atlassian.net"
API_ENDPOINT = f"{JIRA_URL}/rest/api/2/issue/bulk"
EMAIL = "rajat.jana.pvt@gmail.com"
API_TOKEN ="ATATT3xFfGF0y7mRIue3wWI5VY2prPKemHgg5kQDLHm0wqXrW2L0s0nuwrtiKpnJ4SYct9BALtEAAcOsCZiFP8BcZqpUFTEE9qpn-9CKBODRAksXJm89Wwm6aDbw163Q_CGjXonMDRT_bbLGp9Rz8MUj-PXGBgZMLsITohP0KeEJQUJFxi1OyPE=A41FAE03"
PROJECT_KEY = "CCS"

def post_user_stories_to_jira(user_stories):
    issues_to_create = []
    for story in user_stories:
        fields = {
            "project": {"key": PROJECT_KEY},
            "summary": story["user_story"],  # Summary
            "description": "\n".join(story.get("acceptance_criteria", [])),  # Acceptance criteria
            "issuetype": {"name": "Task"},  # Issue type
            "labels": [story.get("user_story_id", "NO_ID")]  # Store ID in labels
        }

        # Only add priority if provided
        if "priority" in story and story["priority"]:
            fields["priority"] = {"name": story["priority"]}

        issues_to_create.append({"fields": fields})

    payload = {"issueUpdates": issues_to_create}
    headers = {"Content-Type": "application/json"}

    response = requests.post(
        API_ENDPOINT,
        headers=headers,
        auth=HTTPBasicAuth(EMAIL, API_TOKEN),
        data=json.dumps(payload)
    )

    if response.status_code == 201:
        print("Bulk issues created successfully!")
        return response.json()
    else:
        print(f"Failed with status code {response.status_code}")
        print(response.text)
        return None
    
###################################################################################################
def post_test_cases_to_jira(test_cases):
    issues_to_create = []
    for tc in test_cases:
        description = (
            f"*Precondition*: {tc.get('precondition', '')}\n"
            f"*Steps*:\n" +
            "\n".join([f"- {step}" for step in tc.get('steps', [])]) +
            f"\n*Expected Result*: {tc.get('expected_result', '')}\n"
            f"*Priority*: {tc.get('priority', '')}\n"
            f"*Tags*: {', '.join(tc.get('tags', []))}"
        )
        issues_to_create.append({
            "fields": {
                "project": {"key": PROJECT_KEY},
                "summary": tc.get("title", tc.get("test_id", "Test Case")),
                "description": description,
                "issuetype": {"name": "Task"}, 
                "labels": tc.get("tags", []),
                "priority": {"name": tc.get("priority", "Medium")},
            }
        })

    payload = {"issueUpdates": issues_to_create}
    headers = {"Content-Type": "application/json"}

    response = requests.post(
        API_ENDPOINT,
        headers=headers,
        auth=HTTPBasicAuth(EMAIL, API_TOKEN),
        data=json.dumps(payload)
    )

    if response.status_code == 201:
        print("Bulk test cases created successfully!")
        return response.json()
    else:
        print(f"Failed with status code {response.status_code}")
        print(response.text)
        return None