'use client';
import * as React from 'react';
import { useState, useEffect } from 'react';
import ImageUploadTab from './ImageUploadTab';  // Updated
import FigmaUserStoriesTab from './FigmaUserStoriesTab';  // New import
import GherkinTab from './GherkinTab';
import TestCasesTab from './TestCasesTab';
import TraceabilityTab from './TraceabilityTab';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Check } from 'lucide-react';
import { cn } from '@/lib/utils';

const steps = [
  { value: 'upload', label: '1. Upload Image' },
  { value: 'user stories', label: '2. User Stories' },
  { value: 'gherkin', label: '3. Gherkin' },
  { value: 'test cases', label: '4. Test Cases' },
  { value: 'traceability', label: '5. Traceability' },
];

export default function FigmaClarifai({ onBack }: { onBack?: () => void }) {
  const [activeTab, setActiveTab] = useState('upload');
  const [completedSteps, setCompletedSteps] = useState<{ [key: string]: boolean }>({
    upload: false,
    'user stories': false,
    gherkin: false,
    'test cases': false,
    traceability: false,
  });
  const [enabledSteps, setEnabledSteps] = useState([0]);  // Only upload initially
  const [userstoriesPayload, setuserstoriesPayload] = useState<any>(null);
  const [userstoriesRequirements, setuserstoriesRequirements] = useState<any[]>([]);
  const [gerkinPayload, setgerkinPayload] = useState<any>(null);
  const [gerkinRequirements, setgerkinRequirements] = useState<any[]>([]);
  const [testcasePayload, settestcasePayload] = useState<any>(null);
  const [testcaseRequirement, settestcaseRequirement] = useState<any[]>([]);
  const [traceabilityRequirements, settraceabilityRequirements] = useState<any[]>([]);
  const [isTraceabilityLoading, setIsTraceabilityLoading] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [extractedRawInfo, setExtractedRawInfo] = useState<string | null>(null);  // New: Store raw_info after extraction

  const combinedPayload = {
    user_stories: userstoriesRequirements,
    gherkin_scenarios: gerkinRequirements,
    test_cases: testcaseRequirement,
  };

  // Reuse your sessionStorage logic
  useEffect(() => {
    sessionStorage.clear();
  }, []);
  useEffect(() => {
    const savedId = sessionStorage.getItem("editingId");
    if (savedId) setEditingId(savedId);
  }, []);
  useEffect(() => {
    if (editingId !== null) {
      sessionStorage.setItem("editingId", editingId);
    } else {
      sessionStorage.removeItem("editingId");
    }
  }, [editingId]);

  const isStepEnabled = (index: number) => index === 0 || enabledSteps.includes(index);

  // New: Handle extraction only (no auto-generate)
  const handleImageUploadComplete = async (imageFile: File) => {
    try {
      setCompletedSteps((prev) => ({ ...prev, upload: true }));

      // Extract info from image
    const formData = new FormData();
    formData.append('file', imageFile);
      const extractResponse = await fetch("http://127.0.0.1:8000/extract-info", {
        method: "POST",
        body: formData,
      });
      if (!extractResponse.ok) throw new Error(`Extract failed: ${extractResponse.status}`);
      const extractResult = await extractResponse.json();
      const rawInfo = extractResult.raw_info;
      if (!rawInfo) throw new Error("No raw_info extracted from image");

      setExtractedRawInfo(rawInfo);  // Set for button handler
      // No tab switch—stay on upload, show button/message in tab
    } catch (error) {
      console.error("Failed to extract info:", error);
      // Handle error (e.g., show toast, revert upload complete)
      setCompletedSteps((prev) => ({ ...prev, upload: false }));
    }
  };

  // New: Handle generate user stories on button click
  const handleGenerateUserStories = async () => {
    if (!extractedRawInfo) return;
    try {
      const userStoriesResponse = await fetch("http://127.0.0.1:8000/generate-userstory", {  // Replace with actual endpoint
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ raw_info: extractedRawInfo }),
      });
      if (!userStoriesResponse.ok) throw new Error(`User stories failed: ${userStoriesResponse.status}`);
      const userStoriesResult = await userStoriesResponse.json();

      // Map response: Add requirement_id = user_story_id (for flat structure)
      const mappedStories = userStoriesResult.user_stories.map((story: any) => ({
        ...story,
        requirement_id: story.user_story_id,  // Treat each as own req
      }));

      setuserstoriesPayload(userStoriesResult);
      setuserstoriesRequirements(mappedStories);
      setEnabledSteps((prev) => [...new Set([...prev, 1])]);  // Enable User Stories
      setActiveTab('user stories');
      setCompletedSteps((prev) => ({ ...prev, 'user stories': true }));
    } catch (error) {
      console.error("Failed to generate user stories:", error);
      // Handle error (e.g., show toast)
    }
  };

  const goTogerkin = (fullPayload: any) => {
    setgerkinPayload(fullPayload);
    setgerkinRequirements(fullPayload.gherkin_scenarios);
    setEnabledSteps((prev) => [...new Set([...prev, 2])]);
    setActiveTab('gherkin');
    setCompletedSteps((prev) => ({ ...prev, gherkin: true }));
  };

  const goTotestcases = (fullPayload: any) => {
    settestcasePayload(fullPayload);
    settestcaseRequirement(fullPayload.test_cases);
    setEnabledSteps((prev) => [...new Set([...prev, 3])]);
    setActiveTab('test cases');
    setCompletedSteps((prev) => ({ ...prev, 'test cases': true }));
  };

  const goToTraceability = async () => {
    try {
      setIsTraceabilityLoading(true);
      const response = await fetch("http://127.0.0.1:8000/traceability", {  // Use Figma-specific if available later
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(combinedPayload),
      });
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      const result = await response.json();
      settraceabilityRequirements(result.traceability);
      setEnabledSteps((prev) => [...new Set([...prev, 4])]);
      setActiveTab('traceability');
      setCompletedSteps((prev) => ({ ...prev, traceability: true }));
    } catch (error) {
      console.error("Failed to submit traceability data:", error);
    } finally {
      setIsTraceabilityLoading(false);
    }
  };

  return (
    <>
      {onBack && (
        <button onClick={onBack} className="mb-4 text-sm text-primary hover:underline">
          ← Back
        </button>
      )}
      <div className="w-full">
        <Tabs value={activeTab} onValueChange={(val) => {
          const currentIndex = steps.findIndex((s) => s.value === val);
          if (isStepEnabled(currentIndex)) setActiveTab(val);
        }}>
          <TabsList className="grid grid-cols-5 w-full bg-[#ececec] dark:bg-[#2e2D2D] rounded-md h-[6.5vh]">
            {steps.map((step, index) => {
              const isCompleted = completedSteps[step.value];
              const isDisabled = !isStepEnabled(index);
              return (
                <TabsTrigger
                  key={step.value}
                  value={step.value}
                  disabled={isDisabled}
                  className={cn(
                    "w-full rounded-md px-2 py-2 text-xs font-medium transition-all flex items-center justify-center gap-2",
                    activeTab === step.value ? 'bg-purple-500 text-white' : 'text-black dark:text-white',
                    isDisabled && 'opacity-50 pointer-events-none cursor-not-allowed'
                  )}
                >
                  <div className={`w-4 h-4 rounded-md border flex items-center justify-center text-[9px] ${
                    isCompleted ? 'bg-green-500 border-green-500' : activeTab === step.value ? 'bg-[#B164FF]' : 'bg-black'
                  }`}>
                    {isCompleted && <Check className="w-2 h-2 text-black" />}
                  </div>
                  {step.label}
                </TabsTrigger>
              );
            })}
          </TabsList>

          <TabsContent value="upload">
            <ImageUploadTab 
              onUploadComplete={handleImageUploadComplete} 
              isUploadComplete={completedSteps.upload}
              extractedRawInfo={extractedRawInfo}  // New prop
              onGenerateUserStories={handleGenerateUserStories}  // New prop
            />
          </TabsContent>
          <TabsContent value="user stories">
            <FigmaUserStoriesTab  // New component
              goTogerkin={goTogerkin}
              userstoriesData={userstoriesRequirements}
              fulluserstoriesdataPayload={userstoriesPayload}
              fullValidatorPayload={null}  // Not used in Figma
              onUpdatedUserStoriesData={setuserstoriesRequirements}
              onUpdateUserStoriesPayload={setuserstoriesPayload}
            />
          </TabsContent>
          <TabsContent value="gherkin">
            <GherkinTab goTotestcases={goTotestcases} gerkinData={gerkinRequirements} fullgerkinDataPayload={userstoriesPayload} />
          </TabsContent>
          <TabsContent value="test cases">
            <TestCasesTab
              goToTraceability={goToTraceability}
              testcaseData={testcaseRequirement}
              fulltestcaseDataPayload={testcasePayload}
              isLoading={isTraceabilityLoading}
              fulluserstoriesPayload={userstoriesPayload}
            />
          </TabsContent>
          <TabsContent value="traceability">
            <TraceabilityTab traceabilityData={traceabilityRequirements} combinedPayload={combinedPayload} />
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
}