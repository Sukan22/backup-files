import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogClose } from "@/components/ui/dialog";

export const ConfigurationPopup = ({ onClose }: { onClose: () => void }) => {
  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Configuration</DialogTitle>
        </DialogHeader>
        <p>This is the Configuration popup content.</p>
      </DialogContent>
    </Dialog>
  );
};
