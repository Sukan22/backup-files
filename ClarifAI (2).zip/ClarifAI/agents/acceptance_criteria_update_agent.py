# agents/acceptance_criteria_agent.py
import logging
import json
from typing import Dict, List, Callable
from tools.prompt_utils import extract_clean_json  # same helper you use for user stories

class AcceptanceCriteriaUpdateAgent:
    def __init__(self, llm_caller: Callable[[str], str]):
        """
        llm_caller: a callable that takes a prompt string and returns the raw LLM text output.
                    This keeps the agent decoupled from a specific LLM provider.
        """
        self.llm_caller = llm_caller

    def run(self, inputs: Dict) -> Dict:
        """
        inputs:
            {
                "description": "<feature description>",
                "story": "<user story text>"
            }
        returns:
            {
                "acceptance_criteria": [ ... list of strings ... ]
            }
        """
        description = inputs.get("description", "").strip()
        story = inputs.get("story", "").strip()

        prompt = f"""
You are a product owner. Your task is to write 5–7 or more acceptance criteria (Given/When/Then) 
based on the provided user story and description.

Your response must contain ONLY the acceptance criteria in this exact JSON format:
[
    {{
        "acceptance_criteria": [
            "criteria 1",
            "criteria 2"
        ]
    }}
]

IMPORTANT:
- Do NOT use Markdown or triple backticks.
- Do NOT add explanations.
- Respond only with a raw JSON object (no markdown, no ```json fences, no explanation).

User Story:
{story}

Description:
{description}
""".strip()

        print("=== FINAL PROMPT ===\n", prompt)
        llm_response = self.llm_caller(prompt).strip()

        # Try parsing clean JSON
        try:
            parsed = extract_clean_json(llm_response)

            # Case 1: list with dict containing "acceptance_criteria"
            if isinstance(parsed, list) and parsed and isinstance(parsed[0], dict) and "acceptance_criteria" in parsed[0]:
                return {"acceptance_criteria": parsed[0]["acceptance_criteria"]}

            # Case 2: already a flat list of strings
            if isinstance(parsed, list) and all(isinstance(x, str) for x in parsed):
                return {"acceptance_criteria": parsed}

            # Case 3: dict with "acceptance_criteria" key
            if isinstance(parsed, dict) and "acceptance_criteria" in parsed:
                return {"acceptance_criteria": parsed["acceptance_criteria"]}

        except Exception as e:
            logging.error(f"Failed to parse LLM response: {e}, raw: {llm_response[:500]}")

        # Fallback: treat as plain text lines
        fallback_list = [line.strip("- ").strip() for line in llm_response.split("\n") if line.strip()]
        return {"acceptance_criteria": fallback_list}
