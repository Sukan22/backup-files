'use client';
import * as React from 'react';
import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Loader2, X } from 'lucide-react';

interface ImageUploadTabProps {
  onUploadComplete: (file: File) => Promise<void>;
  isUploadComplete: boolean;
  extractedRawInfo: string | null;
  onGenerateUserStories: () => Promise<void>;
}

export default function ImageUploadTab({ 
  onUploadComplete, 
  isUploadComplete, 
  extractedRawInfo, 
  onGenerateUserStories 
}: ImageUploadTabProps) {
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  const [isUploadingDoc, setIsUploadingDoc] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showSuccessMessage, setShowSuccessMessage] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [docFile, setDocFile] = useState<File | null>(null);
  const [isDocEnabled, setIsDocEnabled] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [uploadedImageFile, setUploadedImageFile] = useState<File | null>(null);
  const [uploadedDocFile, setUploadedDocFile] = useState<File | null>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const docInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (type: 'image' | 'doc', event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (type === 'image' && !file.type.startsWith('image/')) {
      setError('Please select a valid image file.');
      return;
    }

    setError(null);
    setImageFile(type === 'image' ? file : imageFile);
    setDocFile(type === 'doc' ? file : docFile);
  };

  const handleUpload = async (type: 'image' | 'doc') => {
    const file = type === 'image' ? imageFile : docFile;
    if (!file) {
      setError(`No ${type} file selected.`);
      return;
    }

    setError(null);
    if (type === 'image') setIsUploadingImage(true);
    else setIsUploadingDoc(true);

    try {
      await onUploadComplete(file);
      setShowSuccessMessage(`${type === 'image' ? 'Image' : 'Document'} uploaded successfully!`);
      setTimeout(() => setShowSuccessMessage(null), 3000);
      if (type === 'image') {
        setUploadedImageFile(file);
        setImageFile(null);
        if (imageInputRef.current) imageInputRef.current.value = '';
      } else {
        setUploadedDocFile(file);
        setDocFile(null);
        if (docInputRef.current) docInputRef.current.value = '';
      }
    } catch (err) {
      console.error(`${type} upload error:`, err);
      setError(`Failed to upload ${type}. Please try again.`);
    } finally {
      if (type === 'image') setIsUploadingImage(false);
      else setIsUploadingDoc(false);
    }
  };

  const handleClearFile = (type: 'image' | 'doc') => {
    if (type === 'image') {
      setImageFile(null);
      setUploadedImageFile(null);
      if (imageInputRef.current) imageInputRef.current.value = '';
    } else {
      setDocFile(null);
      setUploadedDocFile(null);
      if (docInputRef.current) docInputRef.current.value = '';
    }
  };

  const handleGenerateClick = async () => {
    setIsGenerating(true);
    try {
      await onGenerateUserStories(); // Sends data to FigmaUserStoriesTab
    } catch (err) {
      console.error('Generation error:', err);
      setError('Generation failed. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="p-8 flex flex-col items-center">
      {/* Main Box */}
      <div className="w-full max-w-4xl bg-[#1E1F1F] border border-[#535458] rounded-lg p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Image Upload Section */}
        <div className="flex flex-col gap-4">
          <p className="text-white text-sm">Select file</p>
          <div className="flex items-center gap-2">
            <input
              ref={imageInputRef}
              type="file"
              accept="image/*"
              onChange={(e) => handleFileChange('image', e)}
              className="hidden"
              id="image-upload"
              disabled={isUploadingImage}
            />
            <Button
              onClick={() => imageInputRef.current?.click()}
              className={`w-[10vw] bg-[#E5E5E5] text-black hover:bg-[#D0D0D0] border border-[#535458] rounded-md py-2 px-3 ${isUploadingImage ? 'opacity-50 cursor-not-allowed' : ''}`}
              disabled={isUploadingImage}
            >
              Choose File
            </Button>
            {imageFile && (
              <div className="flex items-center gap-1">
                <p className="text-[#7C7F84] text-sm">{imageFile.name}</p>
                <Button
                  onClick={() => handleClearFile('image')}
                  className="p-0 bg-transparent hover:bg-transparent min-w-0"
                  title="Clear file"
                >
                  <X className="w-4 h-4 text-[#7C7F84]" />
                </Button>
              </div>
            )}
          </div>
          <p className="text-white text-xs font-semibold">Supported format</p>
          <p className="text-white text-xs">jpg, png, jpeg, svg</p>
          <Button
            onClick={() => handleUpload('image')}
            className={`w-[10vw] bg-[#3B3C3E] text-white border border-[#7A7A7B] rounded-md py-2 px-3 hover:bg-[#4A4B4D] ${!imageFile || isUploadingImage ? 'opacity-50 cursor-not-allowed' : ''}`}
            disabled={!imageFile || isUploadingImage}
          >
            {isUploadingImage ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : 'Upload'}
          </Button>
          {isUploadComplete && uploadedImageFile && (
            <div className="flex items-center gap-1">
              <p className="text-[#73787B] text-sm">Uploaded: {uploadedImageFile.name}</p>
              <Button
                onClick={() => handleClearFile('image')}
                className="p-0 bg-transparent hover:bg-transparent min-w-0"
                title="Clear uploaded file"
              >
                <X className="w-4 h-4 text-[#73787B]" />
              </Button>
            </div>
          )}
        </div>

        {/* Optional Document Upload Section */}
        <div className="flex flex-col gap-4">
          <div className="flex items-center gap-2">
            <Checkbox
              id="doc-checkbox"
              checked={isDocEnabled}
              onCheckedChange={(checked) => setIsDocEnabled(checked as boolean)}
            />
            <label htmlFor="doc-checkbox" className="text-white text-sm">Select document (Optional)</label>
          </div>
          {isDocEnabled && (
            <>
              {/* <p className="text-white text-sm">Select file</p> */}
              <div className="flex items-center gap-2">
                <input
                  ref={docInputRef}
                  type="file"
                  accept="*/*"
                  onChange={(e) => handleFileChange('doc', e)}
                  className="hidden"
                  id="doc-upload"
                  disabled={isUploadingDoc}
                />
                <Button
                  onClick={() => docInputRef.current?.click()}
                  className={`w-[10vw] bg-[#E5E5E5] text-black hover:bg-[#D0D0D0] border border-[#535458] rounded-md py-2 px-3 ${isUploadingDoc ? 'opacity-50 cursor-not-allowed' : ''}`}
                  disabled={isUploadingDoc}
                >
                  Choose File
                </Button>
                {docFile && (
                  <div className="flex items-center gap-1">
                    <p className="text-[#7C7F84] text-sm">{docFile.name}</p>
                    <Button
                      onClick={() => handleClearFile('doc')}
                      className="p-0 bg-transparent hover:bg-transparent min-w-0"
                      title="Clear file"
                    >
                      <X className="w-4 h-4 text-[#7C7F84]" />
                    </Button>
                  </div>
                )}
              </div>
              <p className="text-white text-xs font-semibold">Supported format</p>
              <p className="text-white text-xs">docx, pdf, xls</p>
              <Button
                onClick={() => handleUpload('doc')}
                className={`w-[10vw] bg-[#3B3C3E] text-white border border-[#7A7A7B] rounded-md py-2 px-3 hover:bg-[#4A4B4D] ${!docFile || isUploadingDoc ? 'opacity-50 cursor-not-allowed' : ''}`}
                disabled={!docFile || isUploadingDoc}
              >
                {isUploadingDoc ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : 'Upload'}
              </Button>
              {isUploadComplete && uploadedDocFile && (
                <div className="flex items-center gap-1">
                  <p className="text-[#73787B] text-sm">Uploaded: {uploadedDocFile.name}</p>
                  <Button
                    onClick={() => handleClearFile('doc')}
                    className="p-0 bg-transparent hover:bg-transparent min-w-0"
                    title="Clear uploaded file"
                  >
                    <X className="w-4 h-4 text-[#73787B]" />
                  </Button>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* Bottom Buttons */}
      <div className="flex justify-start gap-4 mt-6 w-full max-w-4xl">
        <Button
          onClick={handleGenerateClick}
          disabled={isGenerating}
          className={`bg-[#1E1F1F] text-[#DBDBDB] border border-[#535458] rounded-md py-2 px-3 hover:bg-[#E5E5E5] hover:text-black transition-colors ${isGenerating ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          Regenerate Response
        </Button>
        <Button
          onClick={handleGenerateClick}
          disabled={!extractedRawInfo || isGenerating}
          className={`bg-[#1E1F1F] text-[#DBDBDB] border border-[#535458] rounded-md py-2 px-3 hover:bg-[#E5E5E5] hover:text-black transition-colors ${!extractedRawInfo || isGenerating ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          Generate User Stories
        </Button>
      </div>

      {/* Messages */}
      {error && <p className="text-red-500 mt-4">Error: {error}</p>}
      {showSuccessMessage && (
        <p className="text-green-600 mt-4 animate-pulse">{showSuccessMessage}</p>
      )}
    </div>
  );
}