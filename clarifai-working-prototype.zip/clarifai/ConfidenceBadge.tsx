// import { Badge } from "@/components/ui/badge";

// interface Props {
//   confidence: number | string; // Allow string or number
// }

// export function ConfidenceBadge({ confidence }: Props) {
//   let className = "p-0.5 text-xs rounded-md ";
//   let displayValue: number;

//   if (typeof confidence === 'string') {
//     // Map string confidence to a number
//     switch (confidence.toLowerCase()) {
//       case 'high':
//         displayValue = 0.8;
//         break;
//       case 'medium':
//         displayValue = 0.5;
//         break;
//       case 'low':
//         displayValue = 0.2;
//         break;
//       default:
//         displayValue = 0;
//     }
//   } else {
//     displayValue = confidence;
//   }

//   // Apply your existing color logic
//   if (displayValue > 0.5) {
//     className += "bg-[#0B6058] text-[#5AB4B2]";
//   } else if (displayValue < 0.5) {
//     className += "bg-[#8E6B74] text-[#83263A]";
//   } else {
//     className += "bg-[#86713D] text-[#F7CB9B]";
//   }

//   return <Badge className={className}>{displayValue.toFixed(2)}</Badge>;
// }
import { Badge } from "@/components/ui/badge";

interface Props {
  confidence: number;
}

export function ConfidenceBadge({ confidence }: Props) {
  let className = "p-0.5 text-xs rounded-md ";

  if (confidence > 0.5) {
    className += "bg-[#0B6058] text-[#5AB4B2]";
  } else if (confidence < 0.5) {
    className += "bg-[#8E6B74] text-[#83263A]";
  } else {
    className += "bg-[#86713D] text-[#F7CB9B]";
  }

  return <Badge className={className}>{confidence.toFixed(2)}</Badge>;
}