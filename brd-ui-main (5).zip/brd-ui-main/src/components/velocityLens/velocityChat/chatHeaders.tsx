'ue client';

//import { useState } from 'react';
import { Button } from "@/components/ui/button";
// import { ConfigurationPopup } from './ConfigurationPopup';
// import { SearchChatPopup}  from "./SearchChatPopup";
// import  ChatHistoryPopup  from "./ChatHistoryPopup";
// import { NewChatPopup } from "./NewChatPopup";
import {
  Settings,
  Search,
  MessageSquare,
  PlusSquare,
} from "lucide-react";
interface ChatTopbarProps {
  onTriggerPopup: (popup: string) => void;
}
export const ChatTopbar = ({ onTriggerPopup }: ChatTopbarProps) => {
  //const [activePopup, setActivePopup] = useState<string | null>(null);

  // const handleClick = (popupName: string) => {
  //   setActivePopup(popupName);
  // };

  // const handleClose = () => {
  //   setActivePopup(null);
  // };

  return (
    <div className="flex justify-end items-end gap-2">
      <Button className='rounded-3xl bg-[#ececec] h-8 dark:bg-[#262626] text-black dark:text-white text-xs hover:bg-black hover:text-white' onClick={() => onTriggerPopup("configuration")}>
        <Settings className="w-3 h-3 " /> Configuration
      </Button>
      <Button  className='rounded-3xl bg-[#ececec] h-8 dark:bg-[#262626] text-black dark:text-white hover:bg-black hover:text-white' onClick={() => onTriggerPopup("search")}>
        <Search className="w-3 h-3" /> Search Chat
      </Button>
      <Button className='rounded-3xl bg-[#ececec] h-8 dark:bg-[#262626] text-black dark:text-white hover:bg-black hover:text-white' onClick={() => onTriggerPopup("history")}>
        <MessageSquare className="w-3 h-3" /> Chat History
      </Button>
      <Button className='rounded-3xl bg-[#ececec] h-8 dark:bg-[#262626] text-black dark:text-white hover:bg-black hover:text-white' onClick={() => onTriggerPopup("new")}>
        <PlusSquare className="w-3 h-3" /> New Chat
      </Button>
    </div>

  );
};
