# agents/image_extractor_agent.py
import os
import base64
import tempfile
from typing import Dict
from cairosvg import svg2png
from google import genai

class ImageExtractorAgent:
    def __init__(self):
        # Hardcoded API key for local testing
        self.api_key = "AIzaSyDrDXGSuO9AaY2YH_2BhVT3hbXFpqIHCAY"  # <-- replace with your real Gemini API key string

    def _convert_svg_to_png(self, svg_bytes: bytes) -> str:
        svg_path = None
        png_path = None
        try:
            with tempfile.NamedTemporaryFile(delete=False, suffix=".svg") as tmp_svg:
                tmp_svg.write(svg_bytes)
                svg_path = tmp_svg.name

            with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as tmp_png:
                png_path = tmp_png.name

            svg2png(url=svg_path, write_to=png_path)

            if svg_path and os.path.exists(svg_path):
                os.unlink(svg_path)

            return png_path
        except Exception as e:
            if svg_path and os.path.exists(svg_path):
                os.unlink(svg_path)
            if png_path and os.path.exists(png_path):
                os.unlink(png_path)
            raise Exception(f"Failed to convert SVG to PNG: {str(e)}")

    def _save_image(self, file_bytes: bytes, ext: str) -> str:
        with tempfile.NamedTemporaryFile(delete=False, suffix=ext) as tmp_img:
            tmp_img.write(file_bytes)
            return tmp_img.name

    def _process_uploaded_file(self, file_bytes: bytes, filename: str) -> str:
        ext = os.path.splitext(filename)[1].lower()
        if ext == ".svg":
            return self._convert_svg_to_png(file_bytes)
        elif ext in [".png", ".jpg", ".jpeg"]:
            return self._save_image(file_bytes, ext)
        else:
            raise ValueError("Unsupported file type. Please upload SVG, PNG, or JPG.")

    def _load_image_as_base64(self, imgpath: str) -> str:
        with open(imgpath, 'rb') as f:
            return base64.b64encode(f.read()).decode('utf-8')

    def run(self, file_bytes: bytes, filename: str) -> Dict:
        png_path = self._process_uploaded_file(file_bytes, filename)
        client = genai.Client(api_key=self.api_key)
        response = client.models.generate_content(
            model='gemini-2.5-flash',
            contents=[
                genai.types.Part.from_bytes(
                    data=base64.b64decode(self._load_image_as_base64(png_path)),
                    mime_type='image/png',
                ),
                # '''Extract all visible structured information from the image by considering all the different fields in the image like information inside boxes without missing any rows and columns including labels, tables, and flows.'''
                '''
Extract all visible structured information from the provided wireframe image with maximum accuracy and completeness.

Requirements:

Full Coverage – Capture every visible element without omission, including:

Text inside boxes, panels, or containers

All rows and columns in tables (no missing cells)

Field labels, placeholders, and helper text

Section headers, subheaders, and captions

Buttons, icons with labels, and actionable elements

Flow indicators (arrows, connectors, step numbers)

Legends, footnotes, and annotations

Preserve Structure – Maintain the original layout hierarchy:

Group related fields under their respective sections

Keep table structures intact with correct row/column order

Preserve sequence in flows and navigation steps

Data Fidelity –

Transcribe text exactly as shown (including casing, punctuation, and special characters)

Include all numeric values, units, and symbols

Do not infer or paraphrase — only capture what is visible

Flow Mapping –

Identify and list all process flows or navigation paths shown in the wireframe

Represent them in sequential order with clear step references

Output Format –

Present extracted data in a structured JSON format

Use nested objects/arrays to reflect hierarchy (e.g., sections → fields → values)

Include a "type" field for each element (e.g., "label", "input_field", "table", "button", "flow_step")

Goal: Produce a complete, structured, and lossless textual representation of the wireframe so that no visual detail is lost and the data can be directly used for analysis, documentation, or automation.
'''
            ]
        )
        return {"raw_info": response.text}
