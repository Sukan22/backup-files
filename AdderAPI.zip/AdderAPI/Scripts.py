import re

def mask_word(text: str, old: str = "GIB", new: str = "ABC") -> str:
   
    if not old or not text:
        return text

    # Normalize old word
    old_lower = old.lower()

    # Build regex: matches the word in any case
    pattern = re.compile(re.escape(old), re.IGNORECASE)

    # def replace(match):
    #     matched = match.group(0)
    #     start, end = match.start(), match.end()

    #     # --- SAFETY CHECK: Is this a whole word or valid identifier part? ---
    #     before_char = text[start-1] if start > 0 else None
    #     after_char = text[end] if end < len(text) else None

    #     # Block replacement if it's part of a regular English word
    #     # e.g. "eligible" has "i" before and "l" after → skip
    #     if before_char and before_char.islower():
    #         return matched  # inside a word like "eligible"
    #     if after_char and after_char.islower():
    #         return matched  # inside a word like "gibberish"

    #     # It's safe → replace with correct casing
    #     if matched.isupper():
    #         return new.upper()
    #     elif matched.islower():
    #         return new.lower()
    #     elif matched[0].isupper():
    #         return new.capitalize()
    #     else:
    #         return new.capitalize()

    # return pattern.sub(replace, text)
    def replace(match):
        matched = match.group(0)
        start, end = match.start(), match.end()

        before_char = text[start-1] if start > 0 else ""
        after_char = text[end] if end < len(text) else ""

        # Only apply strict safety for short words (3–5 letters)
        
        if (before_char.isalpha() and before_char.islower()) and \
           (after_char.isalpha() and after_char.islower()):
            return matched  # ← block "eligible", "GIBbing"

            # For longer sequences (gibretailing, GIBRetailMobile), always replace
            # Because real English words don't contain "gibretail", "tamaraPay", etc.
        if matched.isupper():
            return new.upper()
        elif matched.islower():
            return new.lower()
        elif matched[0].isupper():
            return new.capitalize()
        else:
            return new.capitalize()
        
        
    return pattern.sub(replace, text)

#       ——— EXAMPLE USAGE ———
if __name__ == "__main__":
#    with open("prompt.txt", "r", encoding="utf-8") as file:
#     content = file.read()
    content="""GIB is a great tool. I think gibretailing is fun. The eligible candidate will GIB happily."""
    print("Before → After\n" + "—" * 50)
    masked = mask_word(content, "GIB","ABC")
    print(f"{content}")
    print(f"→ {masked}\n")